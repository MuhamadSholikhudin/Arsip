<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kecamatan_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function getKectam()
    {
        
        $query = "SELECT `kecamatan`.*, `kecamatan`.`nama`
                  FROM `kecamatan` JOIN `desa`
                  ON `kecamatan`.`id_kec` = `desa`.`id_kec`
                ";
        return $this->db->query($query)->result_array();
    }

    public function getTotaldesa()
    {
        $this->db->from('desa');
        $query = $this->db->get();
        $rowcount = $query->num_rows();

        return $rowcount;
    }
}
