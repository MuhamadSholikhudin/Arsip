<?php
class M_kategori extends CI_Model
{
    public function __construct()
    {
        parent:: __construct();
    }

    // function get_kategori()
    // {
    //     $this->db->order_by('id_des', 'ASC');
    //     $query = $this->db->get('desa');
    //     return $query->result();
    // }

    // function get_subkategori($id)
    // {
    //     $hasil = $this->db->query("SELECT * FROM desa WHERE id_kec='$id'");
    //     return $hasil->result();
    // }

    function get_desa($id_kec)
    {
        $this->db->where('id_kec', $id_kec);
        $this->db->order_by('id_des', 'ASC');
        $query = $this->db->get('desa');
        $output = '<option value="" >Pilih Desa</option>';
        foreach($query->result() as $row){
            $output .= '<option value="'.$row->id_des. '" >' . $row->nama . '</option>';
        }

        return $output;
    }

     function get_sub_desa($id_kec)
    {
        $query = $this->db->get_where('desa', ['id_kec' => $id_kec]);
        return $query->result();
    }

    // function get_sub_pilihan($pil)
    // {
    //     $query = $this->db->query("SELECT * namalengkap, jabatan, pendidikan, agama
    //                         FROM aparatur JOIN jabatan ON aparatur.id_jabatan = jabatan.id_jabatan
    //                         JOIN pendidikan ON aparatur.id_pendidikan = pendidikan.id_pendidikan
    //                         JOIN agama ON aparatur.id_agama = agama.id_agama
    //                         WHERE $pil");
    //     return $query->result();
    // }

    function get_sub_pilihan($pil)
    {
        $query = $this->db->query("SELECT *
                            FROM aparatur 
                            WHERE $pil");
        return $query->result();
    }
}
