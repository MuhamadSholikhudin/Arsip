<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 *
 * @author Ando Baramuli
 *
 **/

class M_dashboard extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function getTotalKecamatan()
	{
		$this->db->from('kecamatan');
		$query = $this->db->get();
		$rowcount = $query->num_rows();

		return $rowcount;
	}

	public function getTotalDesa()
	{
		$this->db->from('desa');
		$query = $this->db->get();
		$rowcount = $query->num_rows();

		return $rowcount;
	}

	public function getTotalKepaladesa()
	{
		
		$query = $this->db->query("SELECT * FROM aparatur where id_jabatan = 1");
		
	
		$rowcount = $query->num_rows();

		return $rowcount;
	}

	public function getTotalKasiPem()
	{
		$query = $this->db->query("SELECT * FROM aparatur where id_jabatan = 2");

		$rowcount = $query->num_rows();

		return $rowcount;
	}

	public function getTotalKasiPerencanaan()
	{
		$query = $this->db->query("SELECT * FROM aparatur where id_jabatan = 3");

		$rowcount = $query->num_rows();

		return $rowcount;
	}

	public function getTotalLaki()
	{
		$query = $this->db->query("SELECT * FROM aparatur where jenis_kelamin = 'L' ");

		$rowcount = $query->num_rows();

		return $rowcount;
	}

	public function getTotalPerempuan()
	{
		$query = $this->db->query("SELECT * FROM aparatur where jenis_kelamin = 'P' ");

		$rowcount = $query->num_rows();

		return $rowcount;
	}

}
