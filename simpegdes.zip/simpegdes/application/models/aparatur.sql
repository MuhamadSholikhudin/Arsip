INSERT INTO aparatur
(`id_aparatur`, `namalengkap`, `tempatlahir`, `tanggallahir`, `id_jabatan`, `id_kec`, `id_des`, `rt`, `rw`, 
`id_pendidikan`, `tmtmenjabat`, `tmtpensiun`, `nomersk`, `tanggalsk`, `jenis_kelamin`, `id_agama`, `id_status`) VALUES
('','',[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],
[value-10],[value-11],[value-12],[value-13],[value-14],[value-15],[value-16],[value-17]),

INSERT INTO aparatur
(`id_aparatur`, `namalengkap`, `tempatlahir`, `tanggallahir`, `id_jabatan`, `id_kec`, `id_des`, `rt`, `rw`, 
`id_pendidikan`, `tmtmenjabat`, `tmtpensiun`, `nomersk`, `tanggalsk`, `jenis_kelamin`, `id_agama`, `id_status`) VALUES
('','SUSANTO','Kudus','2020-02-18','1','28.00','28.07.01','','',
'3','29/04/1977','2020-02-18','141.1/479/2013','','L','1','1');


INSERT INTO aparatur
(`id_aparatur`, `namalengkap`, `tempatlahir`, `tanggallahir`, `id_jabatan`, `id_kec`, `id_des`, `rt`, `rw`, 
`id_pendidikan`, `tmtmenjabat`, `tmtpensiun`, `nomersk`, `tanggalsk`, `jenis_kelamin`, `id_agama`, `id_status`) VALUES
('','SUSANTO','Kudus','2020-04-29','1','28.00','28.07.01','','',
'3','2013-12-16','2013-12-17','141.1/479/2013','','L','1','1');

INSERT INTO aparatur
(`id_aparatur`, `namalengkap`, `tempatlahir`, `tanggallahir`, `id_jabatan`, `id_kec`, `id_des`, `rt`, `rw`, 
`id_pendidikan`, `tmtmenjabat`, `tmtpensiun`, `nomersk`, `tanggalsk`, `jenis_kelamin`, `id_agama`, `id_status`) VALUES

('','SUSANTO','Kudus','2020-04-29','1','28.00','28.07.01','','',
'3','2013-12-16','2013-12-17','141.1/479/2013','','L','1','1'), --Kepala desa

('','HUDDA AMRULLAH','','','2','28.00','28.07.01','','',
'3','','','','','L','1','1'), --Sekretaris Desa

('','SHOLIKHATUN','Kudus','1969-08-05','3','28.00','28.07.01','','',
'3','','','','','P','1','1'), --Kepala Seksi Pemerintahan

('','NOOR SALIM','Kudus','1967-04-29','4','28.00','28.07.01','','',
'3','','','','','L','1','1'), --Kepala Seksi Kesejahteraan

('','SABURI','Kudus','1955-05-18','5','28.00','28.07.01','','',
'3','','','','','L','1','1'), --Kepala Seksi Pelayanan

('','SAMIASIH','Kudus','1954-10-08','6','28.00','28.07.01','','',
'3','','','','','P','1','1'), --Kepala Urusan Tata Usaha dan Umum

('','EDY SUTRISNO','Kudus','1984-11-10','7','28.00','28.07.01','','',
'3','','','','','L','1','1'), --Kepala Urusan Keuangan

('','LUTHFI MAULANA RIYANTO','','','8','28.00','28.07.01','','',
'','','','','','L','1','1'), -- 	Kepala Urusan Perencanaan

('','SUMADI','Kudus','1969-09-09','9','28.00','28.07.01','','',
'','','','','','L','1','1'), --Kepala Dusun I

('','ROFIQ','Kudus','1975-09-01','10','28.00','28.07.01','','',
'','','','','','L','1','1'); --Kepala Dusun II

						
INSERT INTO aparatur
(`id_aparatur`, `namalengkap`, `tempatlahir`, `tanggallahir`, `id_jabatan`, `id_kec`, `id_des`, `rt`, `rw`, 
`id_pendidikan`, `tmtmenjabat`, `tmtpensiun`, `nomersk`, `tanggalsk`, `jenis_kelamin`, `id_agama`, `id_status`) VALUES

('','M. ANDHI BAKHTIAR','Kudus','1978-05-29','1','28.00','28.07.01','06','03',
'4','2013-12-16','','141.1/480/2013','2013-12-17','L','1','1'), --Kepala desa

('','ARIF ZAKARIA','','','2','28.00','28.07.01','','',
'','','','','','L','1','1'), --Sekretaris Desa

('','TEGUH TRIYANTO','Kudus','1973-04-06','3','28.00','28.07.01','06','04',
'5','2018-10-30','','141/01/2018','2018-10-30','L','1','1'), --Kepala Seksi Pemerintahan

('','AGUS SUSANTO','Semarang','1967-04-29','4','28.00','28.07.01','09','04',
'3','2018-11-07','','141/01/2018','2018-10-30','L','1','1'), --Kepala Seksi Kesejahteraan

('','MUCH. SAEBUDI','Kudus','1970-07-17','5','28.00','28.07.01','05','03',
'5','2018-11-07','','141/01/2018','2018-10-30','L','1','1'), --Kepala Seksi Pelayanan

('','SUPRAPTI','Kudus','1990-06-06','6','28.00','28.07.01','02','02',
'3','2018-11-07','','141/01/2018','2018-10-30','P','1','1'), --Kepala Urusan Tata Usaha dan Umum

('','KHAULANIA HAIDARANI SUTRISNO','','','7','28.00','28.07.01','','',
'','','','','','P','1','1'), --Kepala Urusan Keuangan

('','MUHAMMAD MASUD','Kudus','1983-10-17','8','28.00','28.07.01','06','01',
'3','2018-11-07','','141/01/2018','2018-10-30','L','1','1'), -- 	Kepala Urusan Perencanaan

('','ENDRA','Kudus','1965-06-27','9','28.00','28.07.01','03','01',
'3','2018-11-07','','141/01/2018','2018-10-30','L','1','1'), --Kepala Dusun I

('','KHOIRUL  HUDA','Kudus','1980-11-02','10','28.00','28.07.01','03','03',
'3','2018-11-07','','141/01/2018','2018-10-30','L','1','1'); --Kepala Dusun II

('','BUKHORI','Kudus','1962-12-02','11','28.00','28.07.01','08','04',
'1','2018-11-07','','141/01/2018','2018-10-30','L','1','1'); --Kepala Dusun III

        			
-- 4	AGUS SUSANTO	Kudus	17 Agustus 1977	Desa	Desa Prambatan Kidul RT. 09 RW. 04	Kepala Seksi Kesejahteraan			SLTA	Islam	L		141/01/2018	30/10/2018	07-Nov-18			
-- 5	MUCH. SAEBUDI	Semarang	17 Juli 1970	Desa	Desa Prambatan Kidul RT. 05 RW. 03	Kepala Seksi Pelayanan			S1	Islam	L		141/01/2018	30/10/2018	07-Nov-18	
-- 6	SUPRAPTI	Kudus	06 Juni 1990	Desa	Desa Prambatan Kidul RT. 02 RW. 02	Kepala Urusan Tata Usaha dan Umum			SLTA	Islam		P	141/01/2018	30/10/2018	07-Nov-18			
-- 7	KHAULANIA HAIDARANI			Desa	Kepala Urusan Keuangan				P			
-- 8	MUHAMMAD MASUD	Kudus	17 Oktober 1983	Desa	Desa Prambatan Kidul RT. 06 RW. 01	Kepala Urusan Perencanaan			SLTA	Islam	L		141/01/2018	30/10/2018	07-Nov-18			
-- 9	ENDRA	Kudus	27 Juni 1965	Desa	Desa Prambatan Kidul RT. 03 RW. 01	Kepala Dusun	I		SLTA	Islam	L		141/01/2018	30/10/2018	07-Nov-18			
-- 10	KHOIRUL  HUDA	Kudus	11 Februari 1980	Desa	Desa Prambatan Kidul RT. 03 RW. 03	Kepala Dusun	II		SLTA	Islam	L		141/01/2018	30/10/2018	07-Nov-18			
-- 11	BUKHORI	Kudus	02 Desember 1962	Desa	Desa Prambatan Kidul RT. 08 RW. 04	Kepala Dusun	III		SD	Islam	L		141/01/2018	30/10/2018	07-Nov-18			
12	INTAN EVA SURYANINGRUM			Desa	-	Staf Seksi Pemerintahan						P						
13	SITI MARYANI			Desa	-	Staf Urusan Keuangan 						P						
