<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <a href="<?= base_url('admin/pengtambah/'); ?>" class="btn btn-danger mb-3">Tambah</a>
    <?= $this->session->flashdata('message'); ?>

    <!-- DATATABLES -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pengguna" width="100%" cellspacing="0">

                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Email</th>
                            <th scope="col">Status</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($users as $usr) : ?>

                            <tr>
                                <th><?= $i; ?></th>
                                <td>
                                    <?= $usr['name']; ?>
                                </td>
                                <td><?= $usr['email']; ?></td>
                                <td>
                                    <?php
                                    $status = $usr['is_active'];

                                    if ($status == 1) {
                                    ?>
                                        <span class="badge badge-primary">Aktif</span>
                                    <?php } else {  ?>
                                        <span class="badge badge-danger">Non-Aktif</span>
                                    <?php }  ?>
                                </td>

                                <td>
                                    <a href="<?= base_url('admin/pengedit/') . $usr['id']; ?>" class="badge badge-secondary">edit</a>
                                </td>
                            </tr>

                            <?php $i++; ?>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->