<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <!-- Area Chart -->
    <div class="col-xl-6 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Pengguna</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <form class="user" method="post" action="<?= base_url('admin/pengeditById/') . $userr['id']; ?>">
                    <div class="form-group">
                        <label for="Email1">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $userr['name']; ?>">
                        <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="Email1">Email</label>
                        <input type="email" class="form-control" id="Email1" aria-describedby="emailHelp" name="email" value="<?= $userr['email']; ?>">
                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                    <a href="<?= base_url('admin/editpassword/') . $userr['id']; ?>" class="btn btn-danger">Edit Password</a>
                    <button type="submit" class="btn btn-primary float-right">Edit User</button>
                </form>
            </div>
        </div>
    </div>



</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->