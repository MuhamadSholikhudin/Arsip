<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <!-- Nested Row within Card Body -->

    <!-- Area Chart -->
    <div class="col-xl-6 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Tambah Pengguna</h6>

            </div>
            <!-- Card Body -->
            <div class="card-body">
                <form class="user" method="post" action="<?= base_url('admin/registration'); ?>">
                    <div class="form-group">
                        <label for="Email1">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" name="name"  value="<?= set_value('name'); ?>">
                        <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="Email1">Email</label>
                        <input type="email" class="form-control" id="Email1" aria-describedby="emailHelp" name="email" value="<?= set_value('email'); ?>">
                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                    <div class=" form-group">
                        <label for="pass1">Password</label>
                        <input type="password" class="form-control" id="pass1" name="password1">
                        <?= form_error('password1', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>
                    <div class="form-group">
                        <label for="pass2">Repeet Password</label>
                        <input type="password" class="form-control" id="pass2" name="password2">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>



</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->