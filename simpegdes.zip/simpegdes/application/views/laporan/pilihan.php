<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <form action="<?= base_url('laporan/pilihan/') ?>" method="post">
        <div class="row">
            <div class="custom-control custom-checkbox form-check-inline">
                <input type="checkbox" class="custom-control-input" id="kepdes" name="check_list[]" value="id_jabatan LIKE '%1%'">
                <label class="custom-control-label" for="kepdes">Kepala Desa</label>
            </div>
            <div class="custom-control custom-checkbox form-check-inline">
                <input type="checkbox" class="custom-control-input" id="casipem" name="check_list[]" value="id_jabatan LIKE '%3%'">
                <label class="custom-control-label" for="casipem">Kasi Pemerintahan</label>
            </div>
            <div class="custom-control custom-checkbox form-check-inline">
                <input type="checkbox" class="custom-control-input" id="laki" name="check_list[]" value="jenis_kelamin LIKE '%L%'">
                <label class="custom-control-label" for="laki">Laki-laki</label>
            </div>
            <div class="custom-control custom-checkbox form-check-inline">
                <input type="checkbox" class="custom-control-input" id="perempuan" name="check_list[]" value="jenis_kelamin LIKE '%P%'">
                <label class="custom-control-label" for="perempuan">Perempuan</label>
            </div>
            <button class="btn btn-primary" type="submit">Kirim</button>
        </div>
    </form>




    <?php foreach ($par as $paa) : ?>
        <div>
            <?= $paa['namalengkap']; ?>
        </div>

    <?php endforeach; ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->