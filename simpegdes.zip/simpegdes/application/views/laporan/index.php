<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-lg-3">
            <h5>JABATAN</h5>
            <?php foreach ($jabatan as $jab) : ?>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="jabatan<?= $jab['id_jabatan']; ?>" name="check_list[]" value="id_jabatan LIKE '<?= $jab['id_jabatan']; ?>%'">
                    <label class="custom-control-label" for="jabatan<?= $jab['id_jabatan']; ?>"><?= $jab['jabatan']; ?></label>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="col-lg-3">
            <h5>PENDIDIKAN</h5>
            <?php foreach ($pendidikan as $pend) : ?>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="pendidikan<?= $pend['id_pendidikan']; ?>" name="check_list[]" value="id_pendidikan LIKE '<?= $pend['id_pendidikan']; ?>%'">
                    <label class="custom-control-label" for="pendidikan<?= $pend['id_pendidikan']; ?>"><?= $pend['pendidikan']; ?></label>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="col-lg-3">
            <h5>JENIS KELAMIN</h5>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="laki" name="check_list[]" value="jenis_kelamin LIKE 'L%'">
                <label class="custom-control-label" for="laki">Laki-laki</label>
            </div>
            <div class="custom-control custom-checkbox mb-3">
                <input type="checkbox" class="custom-control-input" id="perempuan" name="check_list[]" value="jenis_kelamin LIKE 'P%'">
                <label class="custom-control-label" for="perempuan">Perempuan</label>
            </div>

            <h5>STATUS</h5>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="aktif" name="check_list[]" value="id_status LIKE '1%'">
                <label class="custom-control-label" for="aktif">Aktif</label>
            </div>
            <div class="custom-control custom-checkbox mb-3">
                <input type="checkbox" class="custom-control-input" id="nonaktif" name="check_list[]" value="id_status LIKE '0%'">
                <label class="custom-control-label" for="nonaktif">Non-aktif</label>
            </div>
        </div>

        <div class="col-lg-3">
            <h5>AGAMA</h5>
            <?php foreach ($agama as $aga) : ?>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="agama<?= $aga['id_agama']; ?>" name="check_list[]" value="id_agama LIKE '<?= $aga['id_agama']; ?>%'">
                    <label class="custom-control-label" for="agama<?= $aga['id_agama']; ?>"><?= $aga['agama']; ?></label>
                </div>
            <?php endforeach; ?>
        </div>
    </div>



    <div class="row pl-3 mb-4">
        <input id="pilihantampil" class="btn btn-primary" type="submit" name="tampil" value="CARI">
    </div>

    <!-- <div>
        <input id="GFG_DOWN" type="text">
        <input id="GFG_TENGAH" type="text">
        <input id="GFG_ATAS" type="text">
    </div> -->


    <table class="table table-bordered">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">NAMA </th>
                <th scope="col">JABATAN</th>
                <th scope="col">PENDIDIKAN</th>
                <th scope="col">JENIS KELAMIN</th>
                <th scope="col">AGAMA</th>
            </tr>
        </thead>
        <tbody id="tbpil">

        </tbody>
    </table>


    <?php
    // $vegetables[0] = "id_jabatan LIKE %1%";
    // $vegetables[1] = "id_jabatan LIKE %2%";
    // $vegetables[2] = "jenis_kelamin LIKE %'L'%";
    // $vegetables[3] = "jenis_kelamin LIKE %'P'%";
    // $text = implode(" OR ", $vegetables);
    // echo $text;
    ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->