    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

        <div class="row">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Kecamatan</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalkecamatan; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-map fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Desa</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totaldesa; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-map-marker-alt fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Kepala Desa</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalkepaladesa; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user-tie fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Kasi Pemerintahan</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalkasipem; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-fw fa-user-friends fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Kasi Perencanaan</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalkasiperen; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user-tag fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">LAKI-LAKI</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totallaki; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-male fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PEREMPUAN</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalperempuan; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-female fa-3x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




    </div>
    <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->