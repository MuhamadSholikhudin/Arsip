<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newkecamatan">Tambah Kecamatan</a>
    <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

    <?= $this->session->flashdata('message'); ?>


    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Kode Kecamatan</th>
                <th>Kecamatan</th>
                <th>action</th>

            </tr>
        </thead>
        <tbody>
            <tr>

                <?php $i = 1; ?>
                <?php foreach ($kecamatan as $kec) : ?>

                    <th scope="row"><?= $i; ?></th>
                    <td><?= $kec['id_kec']; ?></td>
                    <td><?= $kec['nama']; ?></td>
                    <td>
                        <a href="<?= base_url('admin/editkecamatan/') . $kec['id_kec']; ?>" class="badge badge-success">ubah</a>
                        <a href="<?= base_url('admin/hapuskecamatanById/') . $kec['id_kec']; ?>" class="badge badge-danger">delete</a>
                    </td>
            </tr>
            <?php $i++; ?>
        <?php endforeach; ?>

        </tr>

        </tbody>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="newkecamatan" tabindex="-1" role="dialog" aria-labelledby="newkecamatanLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newkecamatanLabel">Tambah Kecamatan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('admin/kecamatan'); ?>" method="post">
                        <div class="form-group">
                            <input type="text" class="form-control" id="id_kec" name="id_kec" placeholder="Kode Kecamatan">
                        </div>
                        <div class="form-group d-none">
                            <input type="text" class="form-control" id="id_kab" name="id_kab" value="C1">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Kecamatan">
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </div>
            </form>
        </div>
    </div>



</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->