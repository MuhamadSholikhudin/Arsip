<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <form action="<?= base_url('admin/editdesaById'); ?>" method="post">
        <div class="row">
            <div class="col-lg-6 border">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="id_kec" name="id_kec" value="<?= $des['id_kec']; ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="id_des" name="id_des" value="<?= $des['id_des']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Klasifikasi Desa</label>
                        <select class="form-control" id="klasifikasi" name="klasifikasidesa">
                            <?php foreach($klasi as $kla): ?>
                                <?php if($kla == $des['klasifikasidesa']) : ?>
                                    <option value="<?= $kla; ?>" selected><?= $kla; ?></option>
                                <?php else: ?>
                                    <option value="<?= $kla; ?>" ><?= $kla; ?></option>
                                <?php endif ?>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="nama" name="nama" value="<?= $des['nama']; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="<?= base_url('admin/desa/'); ?>" type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary">Ubah</button>
                </div>
            </div>
        </div>

    </form>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->