<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <form action="<?= base_url('admin/editkecamatanById'); ?>" method="post">
        <div class="row">
            <div class="col-lg-6 border">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="id_kec" name="id_kec" value="<?= $kec['id_kec']; ?>">
                    </div>
                    
                    <div class="form-group">
                        <input type="text" class="form-control" id="nama" name="nama" value="<?= $kec['nama']; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="<?= base_url('admin/kecamatan/'); ?>" type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</a>
                    <button type="submit" class="btn btn-primary">Ubah</button>
                </div>
            </div>
        </div>

    </form>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->