<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newdesa">Tambah desa</a>
    <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

    <?= $this->session->flashdata('message'); ?>


    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Kode Kecamatan</th>
                <th scope="col">Kecamatan</th>
                <th scope="col">Kode Desa</th>
                <th>Desa</th>
                <th>Klasifikasi</th>
                <th>Aksi</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <?php $i = 1; ?>
                <?php foreach ($desa as $des) : ?>
                    <th scope="row"><?= $i; ?></th>
                    <td><?= $des['id_kec']; ?></td>
                    <td>
                        <?php
                    $keca = $des['id_kec'];
                    $query = $this->db->query("SELECT * FROM kecamatan where id_kec = '$keca'")->row_array();
                    echo $query['nama'];
                         ?>
                         
                    </td>
                    <td><?= $des['id_des']; ?></td>
                    <td><?= $des['nama']; ?></td>
                    <td><?= $des['klasifikasidesa']; ?></td>
                    <td>
                        <a href="<?= base_url('admin/editdesa/') . $des['id_des']; ?>" class="badge badge-success">ubah</a>
                        <a href="<?= base_url('admin/hapusdesaById/') . $des['id_des']; ?>" class="badge badge-danger">delete</a>
                    </td>
            </tr>
            <?php $i++; ?>
        <?php endforeach; ?>

        </tr>

        </tbody>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="newdesa" tabindex="-1" role="dialog" aria-labelledby="newdesaLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newdesaLabel">Tambah Desa</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?= base_url('admin/desa'); ?>" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <select class="custom-select" id="id_kec" name="id_kec">
                                <?php foreach ($kecamatan as $kec) : ?>
                                    <option value="<?= $kec['id_kec']; ?>"><?= $kec['nama']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="custom-select" id="klasifikasidesa" name="klasifikasidesa">
                                <option value="SWASEMBADA">SWASEMBADA</option>
                                <option value="SWAKARYA">SWAKARYA</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="id_des" name="id_des" placeholder="Kode Wilayah Desa">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Desa">
                        </div>
                        <div class="form-group d-none">
                            <input type="number" class="form-control" id="id_jenis" name="id_jenis" value="4">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->