    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

        <a href="<?= base_url('admin/kecamatan'); ?>" class="mt-4">
            <button type="button" class="btn btn-outline-primary">Kecamatan</button>
        </a>
        <a href="<?= base_url('admin/desa'); ?>" class="ml-4">
            <button type="button" class="btn btn-outline-secondary">Desa</button>
        </a>


    </div>
    <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->