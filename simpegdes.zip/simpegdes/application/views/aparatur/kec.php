<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <?php
    // $queryListApa = "SELECT desa.id_des as hides
    //                         FROM desa JOIN kecamatan ON desa.id_kec = kecamatan.id_kec
    //                         WHERE desa.id_kec = '$id_keca';
    //                     ";
    // $listApa = $this->db->query($queryListApa)->result();


    $id_keca = $kec['id_kec'];
    $query = $this->db->query("SELECT * FROM desa where id_kec = '$id_keca'");
    echo $query->num_rows();
    ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Desa</th>
                    <th>Kepala Desa</th>
                    <th>Sekretaris Desa</th>
                    <th>Kasi Pemerintahan</th>
                    <th>Kasi Kesejahteraan</th>
                    <th>Kasi Pelayanan</th>
                    <th>Kaur TU</th>
                    <th>Kaur Keuangan</th>
                    <th>Kaur Perencanaan</th>
                    <th>Kadus</th>
                    <th>Staff</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($desa as $des) : ?>
                    <tr>
                        <th><?= $i; ?></th>
                        <td>
                            <a href="<?= base_url('user/apardes/') . $des['id_des']; ?>"> <?= $des['nama']; ?></a>
                        </td>
                        <td>
                            <?php
                            $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 1 and id_status = 1");
                            $aktif = $query->num_rows();
                            if ($aktif < 1) {
                            ?>
                                <span class="badge badge-danger">Kosong</span>
                            <?php } else {  ?>
                                <span class="badge badge-primary">Ada</span>
                            <?php }  ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 2");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 3");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 4");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 5");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 6");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 7");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and id_jabatan = 8");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' AND  (id_jabatan = 9 OR id_jabatan = 10 OR id_jabatan = 11 OR id_jabatan = 12) ");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                    $desak = $des['id_des'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_des = '$desak' and (id_jabatan = 13 OR id_jabatan = 14 OR id_jabatan = 15 OR id_jabatan = 16 OR id_jabatan = 17 OR id_jabatan = 18 OR id_jabatan = 19 OR id_jabatan = 20)");
                            echo $query->num_rows();
                            ?>
                        </td>
                    </tr>
                    <?php $i++; ?>
                <?php endforeach; ?>

            </tbody>
        </table>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->