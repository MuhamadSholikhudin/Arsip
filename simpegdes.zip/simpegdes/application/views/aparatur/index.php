<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>



    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>Kecamatan</th>
                    <th>Desa</th>
                    <th>Kepala Desa</th>
                    <th>Sekretaris Desa</th>
                    <th>Kasi Pemerintahan</th>
                    <th>Kasi Kesejahteraan</th>
                    <th>Kasi Pelayanan</th>
                    <th>Kaur TU</th>
                    <th>Kaur Keuangan</th>
                    <th>Kaur Perencanaan</th>
                    <th>Kadus</th>
                    <th>Staff</th>
                    <th>Total</th>

                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($kecamatan as $kec) : ?>
                    <tr>
                        <th><?= $i; ?></th>
                        <td class="text-dark">
                            <a href="<?= base_url('user/aparkec/') . $kec['id_kec']; ?>"> <?= $kec['nama']; ?></a>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM desa where id_kec = '$keca'");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 1");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 2");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 3");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 4");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 5");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 6");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 7");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and id_jabatan = 8");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' AND  (id_jabatan = 9 OR id_jabatan = 10 OR id_jabatan = 11 OR id_jabatan = 12) ");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca' and (id_jabatan = 13 OR id_jabatan = 14 OR id_jabatan = 15 OR id_jabatan = 16 OR id_jabatan = 17 OR id_jabatan = 18 OR id_jabatan = 19 OR id_jabatan = 20 )");
                            echo $query->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                            $keca = $kec['id_kec'];
                            $query = $this->db->query("SELECT * FROM aparatur where id_kec = '$keca'");
                            echo $query->num_rows();
                            ?>
                        </td>
                    </tr>
                    <?php $i++; ?>
                <?php endforeach; ?>
                <!-- Jumlah -->
                <tr>
                    <th></th>
                    <td class="text-dark">
                        Jumlah
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM desa');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 1');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 2');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 3');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 4');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 5');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 6');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 7');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 8');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 9');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        <?php
                        $query = $this->db->query('SELECT * FROM aparatur WHERE id_jabatan = 10');
                        echo $query->num_rows();
                        ?>
                    </td>
                    <td>
                        ?
                    </td>
                </tr>
            </tbody>
        </table>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->