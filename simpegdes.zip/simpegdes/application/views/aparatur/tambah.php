<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tambah Desa</h1>

    <form action="<?= base_url('aparatur/tambahaparatur/') . $desa['id_des']; ?>" method="post">

        <div class="form-group row">
            <label for="namalengkap" class="col-sm-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="namalengkap" name="namalengkap" placeholder="Nama Lengkap">
                <?= form_error('namalengkap', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tempatlahir" class="col-sm-2 col-form-label">Tempat Lahir</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="tempatlahir" name="tempatlahir" placeholder="Kota">
                <?= form_error('tempatlahir', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggallahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tanggallahir" name="tanggallahir">
                <?= form_error('tanggallahir', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_jabatan" name="id_jabatan">
                    <?php foreach ($jabatan as $jab) : ?>
                        <option value="<?= $jab['id_jabatan']; ?>"><?= $jab['jabatan']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_jabatan', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_kec" class="col-sm-2 col-form-label">Kecamatan</label>
            <div class="col-sm-4">
                <?php
                $id_kec = $desa['id_kec'];
                $queryKec = "SELECT kecamatan.id_kec, kecamatan.nama
                            FROM kecamatan JOIN desa
                              ON kecamatan.id_kec = desa.id_kec
                           WHERE desa.id_kec = $id_kec
                        ";
                $kecamatan = $this->db->query($queryKec)->row_array();
                ?>
                <input type="text" class="form-control d-none" id="id_kec" name="id_kec" value="<?= $kecamatan['id_kec']; ?>">
                <input type="text" class="form-control" value="<?= $kecamatan['nama']; ?>" readonly>

            </div>
        </div>
        <div class="form-group row">
            <label for="id_des" class="col-sm-2 col-form-label">Desa</label>
            <div class="col-sm-4">
                <input type="text" class="form-control d-none" id="id_des" name="id_des" value="<?= $desa['id_des']; ?>">
                <input type="text" class="form-control" id="" name="" value="<?= $desa['nama']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="rt" class="col-sm-2 col-form-label text-right">RT</label>
            <div class="col-sm-1 pr-1">
                <input type="text" class="form-control" id="rt" name="rt">
                <?= form_error('rt', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <label for="rw" class="col-sm-1 col-form-label text-right">RW</label>
            <div class="col-sm-1">
                <input type="text" class="form-control" id="rw" name="rw">
                <?= form_error('rw', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_pendidikan" class="col-sm-2 col-form-label">Pendidikan</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_pendidikan" name="id_pendidikan">
                    <?php foreach ($pendidikan as $pend) : ?>
                        <option value="<?= $pend['id_pendidikan']; ?>"><?= $pend['pendidikan']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_pendidikan', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="agama" class="col-sm-2 col-form-label">Agama</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_agama" name="id_agama">
                    <?php foreach ($agama as $aga) : ?>
                        <option value="<?= $aga['id_agama']; ?>"><?= $aga['agama']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_agama', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-4">
                <select class="form-control " id="jenis_kelamin" name="jenis_kelamin">

                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>

                </select>
                <?= form_error('id_agama', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtmenjabat" class="col-sm-2 col-form-label">Tanggal Menjabat</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tmtmenjabat" name="tmtmenjabat">
                <?= form_error('tmtmenjabat', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtpensiun" class="col-sm-2 col-form-label">Tanggal Pensiun</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tmtpensiun" name="tmtpensiun">
                <?= form_error('tmtpensiun', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="nomersk" class="col-sm-2 col-form-label">Nomer SK</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="nomersk" name="nomersk" placeholder="Kota">
                <?= form_error('nomersk', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggalsk" class="col-sm-2 col-form-label">Tanggal SK</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tanggalsk" name="tanggalsk">
                <?= form_error('tanggalsk', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_status" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_status" name="id_status">
                    <option value="1" selected>Aktif</option>
                    <option value="0">Non-aktif</option>
                </select>
                <?= form_error('id_status', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <a href="<?= base_url('aparatur/des/') . $desa['id_des']; ?>" class="btn btn-secondary mb-2 float-right">Tambah</a>

            <label for="tombol" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-4">
                <button type="submit" class="btn btn-primary mb-2 float-right">Tambah</button>
            </div>
        </div>


    </form>

</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->