<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <a href="<?= base_url('aparatur/tambah/' . $desa['id_des']); ?>" class="btn btn-danger mb-3">Tambah</a>
    <?= $this->session->flashdata('message'); ?>

    <table class="table table-striped">
        <?php
        $id_desa = $desa['id_des'];
                $queryListApa = "SELECT *
                            FROM aparatur JOIN jabatan ON aparatur.id_jabatan = jabatan.id_jabatan
                            JOIN pendidikan ON aparatur.id_pendidikan = pendidikan.id_pendidikan
                            JOIN agama ON aparatur.id_agama = agama.id_agama
                            WHERE aparatur.id_status = 1 AND aparatur.id_des = '$id_desa' ORDER BY aparatur.id_jabatan ASC;
                        ";
                $listApa = $this->db->query($queryListApa)->result_array();
        ?>
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Jabatan</th>
                <th scope="col">Pendidikan</th>
                <th scope="col">Agama</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php foreach ($listApa as $apar) : ?>
                
                    <tr>
                        <th><?= $i; ?></th>
                        <td>
                            <?= $apar['namalengkap']; ?>
                        </td>
                        <td><?= $apar['jabatan']; ?></td>
                        <td><?= $apar['pendidikan']; ?></td>
                        <td><?= $apar['agama']; ?></td>
                        <td><?= $apar['jenis_kelamin']; ?></td>
                        <td>
                            <a href="<?= base_url('user/apardesdetail/') . $apar['id_aparatur']; ?>" class="badge badge-success">detail</a>
                            <a href="<?= base_url('user/apardesedit/') . $apar['id_aparatur']; ?>" class="badge badge-secondary">edit</a>
                        </td>
                    </tr>
                    <?php $i++; ?>
                
            <?php endforeach; ?>

        </tbody>
    </table>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->