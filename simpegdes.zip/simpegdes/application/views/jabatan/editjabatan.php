<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <form action="<?= base_url('admin/editjabatanById'); ?>" method="post">
        <div class="row">
            <div class="col-lg-6 border">
                <div class="modal-body">
                    <div class="form-group d-none">
                        <input type="text" class="form-control" id="id_jabatan" name="id_jabatan" value="<?= $jab['id_jabatan']; ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?= $jab['jabatan']; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="<?= base_url('jabatan/index'); ?>" type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary">Ubah</button>
                </div>
            </div>
        </div>

    </form>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->