<?php
$id_aparat = $aparatur['id_aparatur'];
$queryListApa = "SELECT *
    FROM aparatur JOIN jabatan ON aparatur.id_jabatan = jabatan.id_jabatan
    JOIN pendidikan ON aparatur.id_pendidikan = pendidikan.id_pendidikan
    JOIN agama ON aparatur.id_agama = agama.id_agama
    JOIN kecamatan ON aparatur.id_kec = kecamatan.id_kec
    JOIN desa ON aparatur.id_des = desa.id_des
    JOIN status ON aparatur.id_status = status.id_status
    WHERE aparatur.id_aparatur = $id_aparat;
    ";
$listApa = $this->db->query($queryListApa)->row_array();

// JOIN aparatur dan kecamatan mengambil nama kecamatan
$queryListKec = "SELECT *
    FROM aparatur JOIN kecamatan ON aparatur.id_kec = kecamatan.id_kec
    WHERE aparatur.id_aparatur = $id_aparat;
    ";
$listKec = $this->db->query($queryListKec)->row_array();

// JOIN aparatur dan desa mengambil nama desa
$queryListDes = "SELECT *
    FROM aparatur JOIN desa ON aparatur.id_des = desa.id_des
    WHERE aparatur.id_aparatur = $id_aparat;
    ";
$listDes = $this->db->query($queryListDes)->row_array();
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Detail Aparatur Desa <?= $listDes['nama']; ?></h1>

    <form action="<?= base_url('admin/dateditById/'); ?>" method="post">
        <div class="form-group row">
            <label for="namalengkap" class="col-sm-2 col-form-label">ID NAMA</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_aparatur" name="id_aparatur" value="<?= $aparatur['id_aparatur']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="namalengkap" class="col-sm-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?= $aparatur['namalengkap']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="tempatlahir" class="col-sm-2 col-form-label">Tempat Lahir</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="tempatlahir" name="tempatlahir" value="<?= $aparatur['tempatlahir']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggallahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tanggallahir" name="tanggallahir" value="<?= $aparatur['tanggallahir']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="tanggallahir" name="tanggallahir" value="<?= $listApa['jabatan']; ?>" readonly>

            </div>
        </div>
        <div class="form-group row">
            <label for="id_kec" class="col-sm-2 col-form-label">Kecamatan</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_kec" name="id_kec" value="<?= $listKec['nama']; ?>" readonly>

            </div>
        </div>
        <div class="form-group row">
            <label for="id_des" class="col-sm-2 col-form-label">Desa</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_des" name="id_des" value="<?= $listDes['nama']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="rt" class="col-sm-2 col-form-label text-right">RT</label>
            <div class="col-sm-1 pr-1">
                <input type="text" class="form-control" id="rt" name="rt" readonly>
            </div>
            <label for="rw" class="col-sm-1 col-form-label text-right">RW</label>
            <div class="col-sm-1">
                <input type="text" class="form-control" id="rw" name="rw" value="<?= $aparatur['rw']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_pendidikan" class="col-sm-2 col-form-label">Pendidikan</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_pendidikan" name="id_pendidikan" value="<?= $listApa['pendidikan']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="agama" class="col-sm-2 col-form-label">Agama</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_agama" name="id_agama" value="<?= $listApa['agama']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" value="<?= $aparatur['jenis_kelamin']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtmenjabat" class="col-sm-2 col-form-label">Tanggal Menjabat</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" id="tmtmenjabat" name="tmtmenjabat" value="<?= $aparatur['tmtmenjabat']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtpensiun" class="col-sm-2 col-form-label">Tanggal Pensiun</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" id="tmtpensiun" name="tmtpensiun" value="<?= $aparatur['tmtpensiun']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="nomersk" class="col-sm-2 col-form-label">Nomer SK</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="nomersk" name="nomersk" value="<?= $aparatur['nomersk']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggalsk" class="col-sm-2 col-form-label">Tanggal SK</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" id="tanggalsk" name="tanggalsk" value="<?= $aparatur['tanggalsk']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_status" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_status" name="id_status" value="<?= $listApa['status']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">

            <label for="tombol" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-4">
                <a href="<?= base_url('admin/data/'); ?>" class="btn btn-secondary mr-2 float-right">Kembali</a>
            </div>
        </div>
    </form>



</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->