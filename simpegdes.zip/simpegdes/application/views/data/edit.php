<?php
$id_aparat = $aparatur['id_aparatur'];
$queryListApa = "SELECT *
    FROM aparatur JOIN jabatan ON aparatur.id_jabatan = jabatan.id_jabatan
    JOIN pendidikan ON aparatur.id_pendidikan = pendidikan.id_pendidikan
    JOIN agama ON aparatur.id_agama = agama.id_agama
    JOIN kecamatan ON aparatur.id_kec = kecamatan.id_kec
    JOIN desa ON aparatur.id_des = desa.id_des
    JOIN status ON aparatur.id_status = status.id_status
    WHERE aparatur.id_aparatur = $id_aparat;
    ";
$listApa = $this->db->query($queryListApa)->row_array();

// JOIN aparatur dan kecamatan mengambil nama kecamatan
$queryListKec = "SELECT *
    FROM aparatur JOIN kecamatan ON aparatur.id_kec = kecamatan.id_kec
    WHERE aparatur.id_aparatur = $id_aparat;
    ";
$listKec = $this->db->query($queryListKec)->row_array();

// JOIN aparatur dan desa mengambil nama desa
$queryListDes = "SELECT *
    FROM aparatur JOIN desa ON aparatur.id_des = desa.id_des
    WHERE aparatur.id_aparatur = $id_aparat;
    ";
$listDes = $this->db->query($queryListDes)->row_array();
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Detail Aparatur Desa <?= $listDes['nama']; ?></h1>

    <form action="<?= base_url('admin/dateditById/'); ?>" method="post">
        <div class="form-group row">
            <label for="namalengkap" class="col-sm-2 col-form-label">ID NAMA</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="id_aparatur" name="id_aparatur" value="<?= $aparatur['id_aparatur']; ?>" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label for="namalengkap" class="col-sm-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?= $aparatur['namalengkap']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="tempatlahir" class="col-sm-2 col-form-label">Tempat Lahir</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="tempatlahir" name="tempatlahir" value="<?= $aparatur['tempatlahir']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggallahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tanggallahir" name="tanggallahir" value="<?= $aparatur['tanggallahir']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="id_jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-4">
                <select class="form-control" id="id_jabatan" name="id_jabatan">
                    <?php foreach ($jabatan as $jab) : ?>
                        <?php if ($jab['id_jabatan'] == $listApa['id_jabatan']) : ?>
                            <option value="<?= $jab['id_jabatan']; ?>" selected><?= $jab['jabatan']; ?></option>
                        <?php else : ?>
                            <option value="<?= $jab['id_jabatan']; ?>"><?= $jab['jabatan']; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_kecc" class="col-sm-2 col-form-label">Kecamatan</label>
            <div class="col-sm-4">
                <select class="form-control" id="id_kecc" name="id_kec">
                    <?php foreach ($kecamatan as $kec) : ?>
                        <?php if ($kec['id_kec'] == $listKec['id_kec']) : ?>
                            <option value="<?= $kec['id_kec']; ?>" selected><?= $kec['nama']; ?></option>
                        <?php else : ?>
                            <option value="<?= $kec['id_kec']; ?>"><?= $kec['nama']; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_dess" class="col-sm-2 col-form-label">Desa</label>
            <div class="col-sm-4">
                <select class="form-control" id="id_dess" name="id_des">
                    <?php foreach ($desa as $des) : ?>
                        <?php if ($des['id_des'] == $listDes['id_des']) : ?>
                            <option value="<?= $des['id_des']; ?>" selected><?= $des['nama']; ?></option>
                        <?php else : ?>
                            <option value="<?= $des['id_des']; ?>"><?= $des['nama']; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="rt" class="col-sm-2 col-form-label text-right">RT</label>
            <div class="col-sm-1 pr-1">
                <input type="text" class="form-control" id="rt" name="rt" value="<?= $aparatur['rt']; ?>">
            </div>
            <label for="rw" class="col-sm-1 col-form-label text-right">RW</label>
            <div class="col-sm-1">
                <input type="text" class="form-control" id="rw" name="rw" value="<?= $aparatur['rw']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="id_pendidikan" class="col-sm-2 col-form-label">Pendidikan</label>
            <div class="col-sm-4">
                <select class="form-control" id="id_pendidikan" name="id_pendidikan">
                    <?php foreach ($pendidikan as $pend) : ?>
                        <?php if ($pend['id_pendidikan'] == $listApa['id_pendidikan']) : ?>
                            <option value="<?= $pend['id_pendidikan']; ?>" selected><?= $pend['pendidikan']; ?></option>
                        <?php else : ?>
                            <option value="<?= $pend['id_pendidikan']; ?>"><?= $pend['pendidikan']; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="agama" class="col-sm-2 col-form-label">Agama</label>
            <div class="col-sm-4">
                <select class="form-control" id="id_agama" name="id_agama">
                    <?php foreach ($agama as $aga) : ?>
                        <?php if ($aga['id_agama'] == $listApa['id_agama']) : ?>
                            <option value="<?= $aga['id_agama']; ?>" selected><?= $aga['agama']; ?></option>
                        <?php else : ?>
                            <option value="<?= $aga['id_agama']; ?>"><?= $aga['agama']; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-4">
                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                    <?php foreach ($jekel as $jek) : ?>
                        <?php if ($jek == $listApa['jenis_kelamin']) : ?>
                            <option value="<?= $jek; ?>" selected><?= $jek; ?></option>
                        <?php else : ?>
                            <option value="<?= $jek; ?>"><?= $jek; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtmenjabat" class="col-sm-2 col-form-label">Tanggal Menjabat</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" id="tmtmenjabat" name="tmtmenjabat" value="<?= $aparatur['tmtmenjabat']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtpensiun" class="col-sm-2 col-form-label">Tanggal Pensiun</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" id="tmtpensiun" name="tmtpensiun" value="<?= $aparatur['tmtpensiun']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="nomersk" class="col-sm-2 col-form-label">Nomer SK</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="nomersk" name="nomersk" value="<?= $aparatur['nomersk']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggalsk" class="col-sm-2 col-form-label">Tanggal SK</label>
            <div class="col-sm-2">
                <input type="date" class="form-control" id="tanggalsk" name="tanggalsk" value="<?= $aparatur['tanggalsk']; ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="id_status" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-4">
                <select class="form-control" id="id_status" name="id_status">
                    <?php foreach ($status as $sta) : ?>
                        <?php if ($sta['id_status'] == $listApa['id_status']) : ?>
                            <option value="<?= $sta['id_status']; ?>" selected><?= $sta['status']; ?></option>
                        <?php else : ?>
                            <option value="<?= $sta['id_status']; ?>"><?= $sta['status']; ?></option>
                        <?php endif ?>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="form-group row">

            <label for="tombol" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-4">
                <button type="submit" class="btn btn-primary mb-2 float-right">Edit</button>
                <a href="<?= base_url('admin/data/'); ?>" class="btn btn-secondary mr-2 float-right">Kembali</a>
            </div>
        </div>
    </form>



</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->