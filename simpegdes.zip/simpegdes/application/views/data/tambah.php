<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tambah Desa</h1>

    <form action="<?= base_url('admin/dattambahdata/'); ?>" method="post">

        <div class="form-group row">
            <label for="namalengkap" class="col-sm-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="namalengkap" name="namalengkap" placeholder="Nama Lengkap" value="<?= set_value('namalengkap'); ?>">
                <?= form_error('namalengkap', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class=" form-group row">
            <label for="tempatlahir" class="col-sm-2 col-form-label">Tempat Lahir</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="tempatlahir" name="tempatlahir" placeholder="Kota" value="<?= set_value('tempatlahir'); ?>">
                <?= form_error('tempatlahir', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggallahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tanggallahir" name="tanggallahir" value="<?= set_value('tanggallahir'); ?>">
                <?= form_error('tanggallahir', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_jabatan" name="id_jabatan" value="<?= set_value('id_jabatan'); ?>">
                    <?php foreach ($jabatan as $jab) : ?>
                        <option value="<?= $jab['id_jabatan']; ?>"><?= $jab['jabatan']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_jabatan', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_kect" class="col-sm-2 col-form-label">Kecamatan</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_kect" name="id_kec" value="<?= set_value('id_kec'); ?>">
                    <option value="">Pilih Kecamatan</option>

                    <?php foreach ($kecamatan as $kec) : ?>
                        <option value="<?= $kec['id_kec']; ?>"><?= $kec['nama']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_kec', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_dest" class="col-sm-2 col-form-label">Desa</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_dest" name="id_des" value="<?= set_value('id_des'); ?>" disabled>
                    <option value="">Pilih desa</option>
                </select>
                <?= form_error('id_des', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="rt" class="col-sm-2 col-form-label text-right">RT</label>
            <div class="col-sm-1 pr-1">
                <input type="text" class="form-control" id="rt" name="rt" value="<?= set_value('rt'); ?>">
                <?= form_error('rt', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <label for="rw" class="col-sm-1 col-form-label text-right">RW</label>
            <div class="col-sm-1">
                <input type="text" class="form-control" id="rw" name="rw" value="<?= set_value('rw'); ?>">
                <?= form_error('rw', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="id_pendidikan" class="col-sm-2 col-form-label">Pendidikan</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_pendidikan" name="id_pendidikan" value="<?= set_value('id_pendidikan'); ?>">
                    <option value="">Pilih</option>
                    <?php foreach ($pendidikan as $pend) : ?>
                        <option value="<?= $pend['id_pendidikan']; ?>"><?= $pend['pendidikan']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_pendidikan', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="agama" class="col-sm-2 col-form-label">Agama</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_agama" name="id_agama" value="<?= set_value('id_agama'); ?>">
                    <?php foreach ($agama as $aga) : ?>
                        <option value="<?= $aga['id_agama']; ?>"><?= $aga['agama']; ?></option>
                    <?php endforeach; ?>
                </select>
                <?= form_error('id_agama', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-4">
                <select class="form-control " id="jenis_kelamin" name="jenis_kelamin" value="<?= set_value('jenis_kelamin'); ?>">
                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>
                </select>
                <?= form_error('id_agama', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtmenjabat" class="col-sm-2 col-form-label">Tanggal Menjabat</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tmtmenjabat" name="tmtmenjabat" value="<?= set_value('tmtmenjabat'); ?>">
                <?= form_error('tmtmenjabat', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmtpensiun" class="col-sm-2 col-form-label">Tanggal Pensiun</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tmtpensiun" name="tmtpensiun" value="<?= set_value('tmtpensiun'); ?>">
                <?= form_error('tmtpensiun', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="nomersk" class="col-sm-2 col-form-label">Nomer SK</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="nomersk" name="nomersk" placeholder="Nomer Sk" value="<?= set_value('nomersk'); ?>">
                <?= form_error('nomersk', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="tanggalsk" class="col-sm-2 col-form-label">Tanggal SK</label>
            <div class="col-sm-3">
                <input type="date" class="form-control" id="tanggalsk" name="tanggalsk" value="<?= set_value('tanggalsk'); ?>">
                <?= form_error('tanggalsk', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row d-none">
            <label for="id_status" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-4">
                <select class="form-control " id="id_status" name="id_status">
                    <option value="1" selected>Aktif</option>
                    <option value="0">Non-aktif</option>
                </select>
                <?= form_error('id_status', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
        </div>
        <div class="form-group row">
            <a href="<?= base_url('admin/data/') ?>" class="btn btn-secondary mb-2 float-right">Kembali</a>

            <label for="tombol" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-4">
                <button type="submit" class="btn btn-primary mb-2 float-right">Tambah</button>
            </div>
        </div>


    </form>

</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->