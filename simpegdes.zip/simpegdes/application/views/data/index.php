<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <a href="<?= base_url('admin/dattambah/'); ?>" class="btn btn-danger mb-3">Tambah</a>
    <?= $this->session->flashdata('message'); ?>


    <!-- DATATABLES -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="example" width="100%" cellspacing="0">
                    <?php
                    $queryListApa = "SELECT *
                            FROM aparatur JOIN jabatan ON aparatur.id_jabatan = jabatan.id_jabatan
                            JOIN pendidikan ON aparatur.id_pendidikan = pendidikan.id_pendidikan
                            JOIN agama ON aparatur.id_agama = agama.id_agama
                            ;
                        ";
                    $listApa = $this->db->query($queryListApa)->result_array();
                    ?>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Jabatan</th>
                            <th scope="col">Pendidikan</th>
                            <th scope="col">Agama</th>
                            <th scope="col">Jenis Kelamin</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($listApa as $apar) : ?>

                            <tr>
                                <th><?= $i; ?></th>
                                <td>
                                    <?= $apar['namalengkap']; ?>
                                </td>
                                <td><?= $apar['jabatan']; ?></td>
                                <td><?= $apar['pendidikan']; ?></td>
                                <td><?= $apar['agama']; ?></td>
                                <td class="text-center"><?= $apar['jenis_kelamin']; ?></td>
                                <td>
                                    <a href="<?= base_url('admin/datdetail/') . $apar['id_aparatur']; ?>" class="badge badge-success">detail</a>
                                    <a href="<?= base_url('admin/datedit/') . $apar['id_aparatur']; ?>" class="badge badge-secondary">edit</a>
                                    <a href="<?= base_url('admin/dathapus/') . $apar['id_aparatur']; ?>" class="badge badge-danger" onClick="confirm('Hapus aparatur ?')">hapus</a>
                                </td>
                            </tr>
                            <?php $i++; ?>

                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->