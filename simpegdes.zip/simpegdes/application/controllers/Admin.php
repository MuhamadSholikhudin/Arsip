<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->model('m_dashboard');

        $data['totalkecamatan'] = $this->m_dashboard->getTotalKecamatan();
        $data['totaldesa'] = $this->m_dashboard->getTotalDesa();
        $data['totalkepaladesa'] = $this->m_dashboard->getTotalKepaladesa();
        $data['totalkasipem'] = $this->m_dashboard->getTotalKasiPem();
        $data['totalkasiperen'] = $this->m_dashboard->getTotalKasiPerencanaan();
        $data['totallaki'] = $this->m_dashboard->getTotalLaki();
        $data['totalperempuan'] = $this->m_dashboard->getTotalPerempuan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }


    public function role()
    {
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer');
    }


    public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->db->where('id !=', 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role-access', $data);
        $this->load->view('templates/footer');
    }


    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Access Changed!</div>');
    }


    // MENU JABATAN PADA CONTROLLER => jab
    public function jab()
    {
        $data['title'] = 'Jabatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['jabatan'] = $this->db->get('jabatan')->result_array();

        $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('jabatan/index', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert('jabatan', ['jabatan' => $this->input->post('jabatan')]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Jabatan added!</div>');
            redirect('jabatan');
        }
    }

    public function editjabatan($id_jabatan)
    {
        $data['title'] = 'Ubah Jabatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['jab'] = $this->db->get_where('jabatan', ['id_jabatan' => $id_jabatan])->row_array();

        // $this->form_validation->set_rules('nama', 'Full Name', 'required|trim');

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('jabatan/editjabatan', $data);
        $this->load->view('templates/footer');
    }

    public function editjabatanById()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('jabatan', 'jabatan', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('jabatan/index', $data);
            $this->load->view('templates/footer');
        } else {
            $jabatan = $this->input->post('jabatan');
            $id_jabatan = $this->input->post('id_jabatan');

            $this->db->set('jabatan', $jabatan);
            $this->db->set('id_jabatan', $id_jabatan);
            $this->db->where('id_jabatan', $id_jabatan);
            $this->db->update('jabatan');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Jabatan Berhasil Di Ubah</div>');
            redirect('jabatan/index');
        }
    }

    public function hapusjabatanById($id_jabatan)
    {
        $this->db->where('id_jabatan', $id_jabatan);
        $this->db->delete('jabatan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Jabatan Berhasil Di Hapus</div>');
        redirect('jabatan/index');
    }


    // MENU DATA PADA CONTROLLLER = > dat
    public function data()
    {
        $data['title'] = 'Data Master';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/index', $data);
        $this->load->view('templates/footer');
    }

    public function dattambah()
    {
        $data['title'] = 'Tambah DATA APARATUR';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/tambah', $data);
        $this->load->view('templates/footer');
    }

    public function dattambahdata()
    {
        $data['title'] = 'Tambah DATA APARATUR';

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('tempatlahir', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tanggallahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('id_jabatan', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_kec', 'Kecamatan', 'required');
        $this->form_validation->set_rules('id_des', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_pendidikan', 'Pendidikan', 'required');
        $this->form_validation->set_rules('id_agama', 'Agama', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');


        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('data/tambah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert(
                'aparatur',
                [
                    'namalengkap' => $this->input->post('namalengkap'),
                    'tempatlahir' => $this->input->post('tempatlahir'),
                    'tanggallahir' => $this->input->post('tanggallahir'),
                    'id_jabatan' => $this->input->post('id_jabatan'),
                    'id_kec' => $this->input->post('id_kec'),
                    'id_des' => $this->input->post('id_des'),
                    'rt' => $this->input->post('rt'),
                    'rw' => $this->input->post('rw'),
                    'id_pendidikan' => $this->input->post('id_pendidikan'),
                    'tmtmenjabat' => $this->input->post('tmtmenjabat'),
                    'tmtpensiun' => $this->input->post('tmtpensiun'),
                    'id_agama' => $this->input->post('id_agama'),
                    'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                    'nomersk' => $this->input->post('nomersk'),
                    'tanggalsk' => $this->input->post('tanggalsk'),
                    'id_status' => $this->input->post('id_status')
                ]
            );
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur baru sukses ditambahkan!</div>');
            redirect('admin/data/');
        }
    }

    public function datedit($id_aparatur)
    {
        $data['title'] = 'Edit Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['status'] = $this->db->get('status')->result_array();
        $data['jekel'] = ['L', 'P'];

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/edit', $data);
        $this->load->view('templates/footer');
    }

    public function datdetail($id_aparatur)
    {
        $data['title'] = 'Edit Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['status'] = $this->db->get('status')->result_array();
        $data['jekel'] = ['L', 'P'];

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/detail', $data);
        $this->load->view('templates/footer');
    }

    public function dateditById()
    {
        $data['title'] = 'Edit Aparatur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->row_array();
        // $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('data', $data);
            $this->load->view('templates/footer');
        } else {
            $id_aparatur = $this->input->post('id_aparatur');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $tanggallahir = $this->input->post('tanggallahir');
            $id_jabatan = $this->input->post('id_jabatan');
            $id_kec = $this->input->post('id_kec');
            $id_des = $this->input->post('id_des');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $id_pendidikan = $this->input->post('id_pendidikan');
            $id_agama = $this->input->post('id_agama');
            $tmtmenjabat = $this->input->post('tmtmenjabat');
            $tmtpensiun = $this->input->post('tmtpensiun');
            $nomersk = $this->input->post('nomersk');
            $tanggalsk = $this->input->post('tanggalsk');
            $id_status = $this->input->post('id_status');

            $this->db->set('namalengkap', $namalengkap);
            $this->db->set('tempatlahir', $tempatlahir);
            $this->db->set('tanggallahir', $tanggallahir);
            $this->db->set('id_jabatan', $id_jabatan);
            $this->db->set('id_kec', $id_kec);
            $this->db->set('id_des', $id_des);
            $this->db->set('rt', $rt);
            $this->db->set('rw', $rw);
            $this->db->set('id_pendidikan', $id_pendidikan);
            $this->db->set('id_agama', $id_agama);
            $this->db->set('tmtmenjabat', $tmtmenjabat);
            $this->db->set('tmtpensiun', $tmtpensiun);
            $this->db->set('nomersk', $nomersk);
            $this->db->set('tanggalsk', $tanggalsk);
            $this->db->set('id_status', $id_status);
            $this->db->where('id_aparatur', $id_aparatur);
            $this->db->update('aparatur');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur Berhasil Di Ubah</div>');
            redirect('admin/data/');
        }
    }

    public function dathapus($id_aparatur)
    {
        $this->db->where('id_aparatur', $id_aparatur);
        $this->db->delete('aparatur');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur Berhasil Di Hapus</div>');
        redirect('admin/data/');
    }

    function get_subkategori()
    {
        $this->load->model('M_kategori', 'dep_kategori', TRUE);
        $id_kec = $this->input->post('id_kec');
        $desas = $this->dep_kategori->get_sub_desa($id_kec);
        if (count($desas) > 0) {
            $des_select_box = '';
            $des_select_box .= '<option value="" >Pilih Desa</option>';
            foreach ($desas as $desa) {
                $des_select_box .= '<option value="' . $desa->id_des . '" >' . $desa->nama . '</option>';
            }
            echo json_encode($des_select_box);
        }
    }


    //  MENU KODE WILAYAH PADA CONTROLLER => kod
    public function kodewilayah()
    {
        $data['title'] = 'Kode Wilayah';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/index', $data);
        $this->load->view('templates/footer');
    }

    public function kecamatan()
    {
        $data['title'] = 'Kode Wilayah';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();

        $this->form_validation->set_rules('id_kec', 'id_kec', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('id_kab', 'id_kab', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/kecamatan', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert(
                'kecamatan',
                [
                    'id_kec' => $this->input->post('id_kec'),
                    'id_kab' => $this->input->post('id_kab'),
                    'nama' => $this->input->post('nama')
                ]
            );
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Tambahkan!</div>');
            redirect('admin/kecamatan');
        }
    }

    public function editkecamatan($id_kec)
    {
        $data['title'] = 'Ubah Kecamatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kec'] = $this->db->get_where('kecamatan', ['id_kec' => $id_kec])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/editkecamatan', $data);
        $this->load->view('templates/footer');
    }

    public function editkecamatanById()
    {
        $data['title'] = 'Kode Wilayah Kecamatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('id_kec', 'Kode Kecamatan', 'required|trim');
        $this->form_validation->set_rules('nama', 'Nama Kecamatan', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/kecamatan', $data);
            $this->load->view('templates/footer');
        } else {
            $id_kec = $this->input->post('id_kec');
            $nama = $this->input->post('nama');
            $id_kab = $this->input->post('id_kab');

            $this->db->set('id_kab', $id_kab);
            $this->db->set('nama', $nama);
            $this->db->where('id_kec', $id_kec);
            $this->db->update('kecamatan');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Ubah</div>');
            redirect('admin/kecamatan');
        }
    }

    public function hapuskecamatanById($id_kec)
    {
        $this->db->where('id_kec', $id_kec);
        $this->db->delete('kecamatan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Hapus</div>');
        redirect('admin/kecamatan');
    }


    public function desa()
    {
        $data['title'] = 'Kode Wilayah Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();

        $this->form_validation->set_rules('id_kec', 'id_kec', 'required');
        $this->form_validation->set_rules('klasifikasidesa', 'klasifikasidesa', 'required');
        $this->form_validation->set_rules('id_des', 'id_des', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/desa', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert(
                'desa',
                [
                    'id_kec' => $this->input->post('id_kec'),
                    'klasifikasidesa' => $this->input->post('klasifikasidesa'),
                    'id_des' => $this->input->post('id_des'),
                    'nama' => $this->input->post('nama'),
                    'id_jenis' => $this->input->post('id_jenis')
                ]
            );
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Desa Berhasil Di Tambahkan!</div>');
            redirect('admin/desa');
        }
    }

    public function editdesa($id_des)
    {
        $data['title'] = 'Ubah Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['des'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();
        $data['klasi'] = ['SWASEMBADA', 'SWAKARYA'];

        $this->form_validation->set_rules('nama', 'Nama Desa', 'required|trim');

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/editdesa', $data);
        $this->load->view('templates/footer');
    }

    public function editdesaById()
    {
        $data['title'] = 'Edit Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('id_kec', 'Kode Kecamatan', 'required|trim');
        $this->form_validation->set_rules('id_des', 'Kode Desa', 'required|trim');
        $this->form_validation->set_rules('nama', 'Nama Desa', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/desa', $data);
            $this->load->view('templates/footer');
        } else {
            $id_des = $this->input->post('id_des');
            $id_kec = $this->input->post('id_kec');
            $nama = $this->input->post('nama');
            $klasifikasidesa = $this->input->post('klasifikasidesa');

            $this->db->set('id_kec', $id_kec);
            $this->db->set('nama', $nama);
            $this->db->set('klasifikasidesa', $klasifikasidesa);
            $this->db->where('id_des', $id_des);
            $this->db->update('desa');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Desa Berhasil Di Ubah</div>');
            redirect('admin/desa');
        }
    }

    public function hapusdesaById($id_des)
    {
        $this->db->where('id_des', $id_des);
        $this->db->delete('desa');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Desa Berhasil Di Hapus</div>');
        redirect('admin/desa');
    }

    // MENU PENGGUNA CONTROLLER => peng
    public function pengguna()
    {
        $data['title'] = 'Pengguna';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['users'] = $this->db->get('user')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengguna/index', $data);
        $this->load->view('templates/footer', $data);
    }

    public function pengtambah()
    {
        $data['title'] = 'Buat Pengguna';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengguna/tambah', $data);
        $this->load->view('templates/footer', $data);
    }


    public function registration()
    {

        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]', [
            'is_unique' => 'This email has already registered!'
        ]);
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[3]|matches[password2]', [
            'matches' => 'Password tidak sama!',
            'min_length' => 'Password terlalu pendek!'
        ]);
        $this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Buat Pengguna';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('pengguna/tambah', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $email = $this->input->post('email', true);
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($email),
                'image' => 'default.jpg',
                'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
                'role_id' => 2,
                'is_active' => 1,
                'date_created' => time()
            ];


            $this->db->insert('user', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Congratulation! your account has been created. Please activate your account</div>');
            redirect('admin/pengguna');
        }
    }

    public function pengedit($id)
    {
        $data['title'] = 'Edit Pengguna';

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['userr'] = $this->db->get_where('user', ['id' => $id])->row_array();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengguna/edit', $data);
        $this->load->view('templates/footer', $data);
    }

    public function pengeditById($id)
    {
        $data['title'] = 'Edit Pengguna';

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->form_validation->set_rules('name', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('pengguna/edit/' . $id, $data);
            $this->load->view('templates/footer');
        } else {

            $name = $this->input->post('name');
            $email = $this->input->post('email');


            $this->db->set('name', $name);
            $this->db->set('email', $email);
            $this->db->where('id', $id);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pengguna Berhasil Di Ubah</div>');
            redirect('admin/pengguna/');
        }
    }

    public function editpassword($id)
    {
        $data['title'] = 'Ubah Password';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['userr'] = $this->db->get_where('user', ['id' => $id])->row_array();


        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[3]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[3]|matches[new_password1]');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('pengguna/editpassword', $data);
            $this->load->view('templates/footer');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');
            if (!password_verify($current_password, $data['userr']['password'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password lama salah</div>');
                redirect('admin/editpassword/' . $id);
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password baru Tidak Boleh sama dengan password lama!</div>');
                    redirect('admin/editpassword/' . $id);
                } else {
                    // password sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('id', $id);
                    $this->db->update('user');

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Mengubah Password</div>');
                    redirect('admin/pengguna/');
                }
            }
        }
    }

    public function penghapus($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('user');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pengguna Berhasil Di Hapus</div>');
        redirect('admin/pengguna/');
    }


}
