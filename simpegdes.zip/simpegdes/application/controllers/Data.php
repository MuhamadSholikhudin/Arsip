<?php
defined('BASEPATH') or exit('No direct script acces allowed');

class Data extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    public function index()
    {
        $data['title'] = 'Data Master';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['title'] = 'Tambah DATA APARATUR';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/tambah', $data);
        $this->load->view('templates/footer');
    }

    public function tambahdata()
    {
        $data['title'] = 'Tambah DATA APARATUR';

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('tempatlahir', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tanggallahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('id_jabatan', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_kec', 'Kecamatan', 'required');
        $this->form_validation->set_rules('id_des', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_pendidikan', 'Pendidikan', 'required');
        $this->form_validation->set_rules('id_agama', 'Agama', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');


        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('data/tambah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert(
                'aparatur',
                [
                    'namalengkap' => $this->input->post('namalengkap'),
                    'tempatlahir' => $this->input->post('tempatlahir'),
                    'tanggallahir' => $this->input->post('tanggallahir'),
                    'id_jabatan' => $this->input->post('id_jabatan'),
                    'id_kec' => $this->input->post('id_kec'),
                    'id_des' => $this->input->post('id_des'),
                    'rt' => $this->input->post('rt'),
                    'rw' => $this->input->post('rw'),
                    'id_pendidikan' => $this->input->post('id_pendidikan'),
                    'tmtmenjabat' => $this->input->post('tmtmenjabat'),
                    'tmtpensiun' => $this->input->post('tmtpensiun'),
                    'id_agama' => $this->input->post('id_agama'),
                    'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                    'nomersk' => $this->input->post('nomersk'),
                    'tanggalsk' => $this->input->post('tanggalsk'),
                    'id_status' => $this->input->post('id_status')
                ]
            );
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur baru sukses ditambahkan!</div>');
            redirect('data/index/');
        }
    }

    public function edit($id_aparatur)
    {
        $data['title'] = 'Edit Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['status'] = $this->db->get('status')->result_array();
        $data['jekel'] = ['L', 'P'];

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/edit', $data);
        $this->load->view('templates/footer');
    }

    public function detail($id_aparatur)
    {
        $data['title'] = 'Edit Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['status'] = $this->db->get('status')->result_array();
        $data['jekel'] = ['L', 'P'];

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/detail', $data);
        $this->load->view('templates/footer');
    }

    public function editById()
    {
        $data['title'] = 'Edit Aparatur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->row_array();
        // $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('data', $data);
            $this->load->view('templates/footer');
        } else {
            $id_aparatur = $this->input->post('id_aparatur');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $tanggallahir = $this->input->post('tanggallahir');
            $id_jabatan = $this->input->post('id_jabatan');
            $id_kec = $this->input->post('id_kec');
            $id_des = $this->input->post('id_des');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $id_pendidikan = $this->input->post('id_pendidikan');
            $id_agama = $this->input->post('id_agama');
            $tmtmenjabat = $this->input->post('tmtmenjabat');
            $tmtpensiun = $this->input->post('tmtpensiun');
            $nomersk = $this->input->post('nomersk');
            $tanggalsk = $this->input->post('tanggalsk');
            $id_status = $this->input->post('id_status');

            $this->db->set('namalengkap', $namalengkap);
            $this->db->set('tempatlahir', $tempatlahir);
            $this->db->set('tanggallahir', $tanggallahir);
            $this->db->set('id_jabatan', $id_jabatan);
            $this->db->set('id_kec', $id_kec);
            $this->db->set('id_des', $id_des);
            $this->db->set('rt', $rt);
            $this->db->set('rw', $rw);
            $this->db->set('id_pendidikan', $id_pendidikan);
            $this->db->set('id_agama', $id_agama);
            $this->db->set('tmtmenjabat', $tmtmenjabat);
            $this->db->set('tmtpensiun', $tmtpensiun);
            $this->db->set('nomersk', $nomersk);
            $this->db->set('tanggalsk', $tanggalsk);
            $this->db->set('id_status', $id_status);
            $this->db->where('id_aparatur', $id_aparatur);
            $this->db->update('aparatur');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur Berhasil Di Ubah</div>');
            redirect('data/');
        }
    }

    public function hapus($id_aparatur)
    {
        $this->db->where('id_aparatur', $id_aparatur);
        $this->db->delete('aparatur');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur Berhasil Di Hapus</div>');
        redirect('data/');
    }

    function get_subkategori(){
        $this->load->model('M_kategori', 'dep_kategori', TRUE);
        $id_kec = $this->input->post('id_kec');
        $desas = $this->dep_kategori->get_sub_desa($id_kec);
        if(count($desas) > 0)
        {
            $des_select_box = '';
            $des_select_box .= '<option value="" >Pilih Desa</option>';
            foreach($desas as $desa){
                $des_select_box .= '<option value="'. $desa->id_des .'" >' . $desa->nama . '</option>';
            }
            echo json_encode($des_select_box);
        }
    }

}
