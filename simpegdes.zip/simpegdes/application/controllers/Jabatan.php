<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jabatan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    
    public function index()
    {
        $data['title'] = 'Jabatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['jabatan'] = $this->db->get('jabatan')->result_array();

        $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('jabatan/index', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert('jabatan', ['jabatan' => $this->input->post('jabatan')]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Jabatan added!</div>');
            redirect('jabatan');
        }
    }

    public function editjabatan($id_jabatan)
    {
        $data['title'] = 'Ubah Jabatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['jab'] = $this->db->get_where('jabatan', ['id_jabatan' => $id_jabatan])->row_array();

        // $this->form_validation->set_rules('nama', 'Full Name', 'required|trim');

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('jabatan/editjabatan', $data);
        $this->load->view('templates/footer');
    }

    public function editjabatanById()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('jabatan', 'jabatan', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('jabatan/index', $data);
            $this->load->view('templates/footer');
        } else {
            $jabatan = $this->input->post('jabatan');
            $id_jabatan = $this->input->post('id_jabatan');
          
            $this->db->set('jabatan', $jabatan);
            $this->db->set('id_jabatan', $id_jabatan);
            $this->db->where('id_jabatan', $id_jabatan);
            $this->db->update('jabatan');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Ubah</div>');
            redirect('jabatan/index');
        }
    }

    public function hapusjabatanById($id_jabatan)
    {
        $this->db->where('id_jabatan', $id_jabatan);
        $this->db->delete('jabatan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Hapus</div>');
        redirect('jabatan/index');
    }

}
