<?php
defined('BASEPATH') or exit ('No direct script acces allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    
    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       
        $this->load->model('m_dashboard');
       
        $data['totalkecamatan'] = $this->m_dashboard->getTotalKecamatan();
        $data['totaldesa'] = $this->m_dashboard->getTotalDesa();
        $data['totalkepaladesa'] = $this->m_dashboard->getTotalKepaladesa();
        $data['totalkasipem'] = $this->m_dashboard->getTotalKasiPem();
        $data['totalkasiperen'] = $this->m_dashboard->getTotalKasiPerencanaan();
        $data['totallaki'] = $this->m_dashboard->getTotalLaki();
        $data['totalperempuan'] = $this->m_dashboard->getTotalPerempuan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('dashboard/index', $data);
        $this->load->view('templates/footer');
    }
}