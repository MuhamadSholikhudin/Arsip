<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    public function index()
    {
        $data['title'] = 'Laporan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['aparatur'] = $this->db->get('aparatur')->result_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('laporan/index', $data);
        $this->load->view('templates/footer');
    }

    // public function get_pilihan()
    // {
    //     $this->load->model('M_kategori', 'dep_kategori', TRUE);
    //     $pil = $this->input->post('pil');
    //     $pilih = $this->dep_kategori->get_sub_pilihan($pil);

    //     $data_tabel = '';
    //     if (count($pilih) > 0) {
    //         $i = 1;
    //         foreach ($pilih as $pi) {
    //             $data_tabel .= '
    //                             <tr>
    //                                 <td>' . $i. '</td>
    //                                 <td>'. $pi->namalengkap . ' </td>
    //                                 <td>' . $pi->id_jabatan . ' </td>
    //                                 <td>' . $pi->id_pendidikan . ' </td>
    //                                 <td>' . $pi->jenis_kelamin . ' </td>
    //                                 <td>' . $pi->id_agama . ' </td>
    //                             </tr>
    //                             ';
    //             $i++;
    //         }
    //         echo json_encode($data_tabel);
    //     }
    //     elseif(count($pilih) == 0){

    //         $alert = '<tr>
    //                     <td colspan="5" class="text-center" >DATA TIDAK ADA</td>
    //                  </tr>';
    //         echo json_encode($alert);
    //     }

    // }


    public function get_pilihan()
    {
        $this->load->model('M_kategori', 'dep_kategori', TRUE);
        $pil = $this->input->post('pil');
        $pilih = $this->dep_kategori->get_sub_pilihan($pil);

        if (count($pilih) > 0) {
            
            echo json_encode($pilih);
        } elseif (count($pilih) == 0) {

            $alert = '<tr>
                        <td colspan="5" class="text-center" >DATA TIDAK ADA</td>
                     </tr>';
            echo json_encode($alert);
        }
    }
}