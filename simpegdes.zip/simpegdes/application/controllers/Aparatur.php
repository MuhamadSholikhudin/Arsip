<?php
defined('BASEPATH') or exit('No direct script acces allowed');

class Aparatur extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Aparatur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();


        // $select = [
        //     'count(desa.id_des) as total'
        // ];
        // $data['keca'] = $this->db
        //     ->select($select)
        //     ->from('desa')
        //     ->join('kecamatan', 'desa.id_kec = kecamatan.id_kec')
        //     ->get()
            // ->where('kecamatan.id_kec', $kec['id_kec'])
            // ->result_array();

        // $this->db->select('SalerName, count(*)');
        // $this->db->from('tblSaler');
        // $this->db->join('tblProduct', 'tblSaler.SalerID = tblProduct.SalerID');
        // $this->db->group_by('tblSaler.SalerID');
        // $data = $this->db->get();
        // $data['totaldesa'] = $this->Kecamatan_model->getTotaldesa();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/index', $data);
        $this->load->view('templates/footer');
    }

    public function kec($id_kec)
    {
        $data['title'] = 'Kecamatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kec'] = $this->db->get_where('kecamatan', ['id_kec' => $id_kec])->row_array();        
        $data['desa'] = $this->db->get_where('desa', ['id_kec' => $id_kec])->result_array();

        

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/kec', $data);
        
        $this->load->view('templates/footer');
    }

    public function des($id_des)
    {
        $data['title'] = 'Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_des' => $id_des])->result_array();
        // $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/des', $data);
        $this->load->view('templates/footer');
    }
    public function tambah($id_des)
    {

        $data['title'] = 'Tambah Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/tambah', $data);
        $this->load->view('templates/footer');
    }

    public function tambahaparatur($id_des)
    {
        $data['title'] = 'Tambah Desa';

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('tempatlahir', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tanggallahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('id_jabatan', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_pendidikan', 'Pendidikan', 'required');
        $this->form_validation->set_rules('id_agama', 'Agama', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');


        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('aparatur/tambah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert('aparatur', 
                    [
                    'namalengkap' => $this->input->post('namalengkap'),
                    'tempatlahir' => $this->input->post('tempatlahir'),
                    'tanggallahir' => $this->input->post('tanggallahir'),
                    'id_jabatan' => $this->input->post('id_jabatan'),
                    'id_kec' => $this->input->post('id_kec'),
                    'id_des' => $this->input->post('id_des'),
                    'rt' => $this->input->post('rt'),
                    'rw' => $this->input->post('rw'),
                    'id_pendidikan' => $this->input->post('id_pendidikan'),
                    'tmtmenjabat' => $this->input->post('tmtmenjabat'),
                    'tmtpensiun' => $this->input->post('tmtpensiun'),
                    'id_agama' => $this->input->post('id_agama'),
                    'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                    'nomersk' => $this->input->post('nomersk'),
                    'tanggalsk' => $this->input->post('tanggalsk'),
                    'id_status' => $this->input->post('id_status')
                    ]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New menu added!</div>');
            redirect('aparatur/des/' . $id_des );
        }
    }

    public function desdetail($id_aparatur)
    {
        $data['title'] = 'Detail Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/desdetail', $data);
        $this->load->view('templates/footer');
    }

    public function desedit($id_aparatur)
    {

        $data['title'] = 'Edit Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->row_array();
        $data['desa'] = $this->db->get('desa')->row_array();
        $data['status'] = $this->db->get('status')->result_array();
        $data['jekel'] = ['L', 'P'];

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/desedit', $data);
        $this->load->view('templates/footer');
    }

    public function deseditById($id_des)
    {
        $data['title'] = 'Edit Aparatur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->row_array();
        // $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');
        
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('aparatur/des', $data);
            $this->load->view('templates/footer');
        } else {
            $id_aparatur = $this->input->post('id_aparatur');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $tanggallahir = $this->input->post('tanggallahir');
            $id_jabatan = $this->input->post('id_jabatan');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $id_pendidikan = $this->input->post('id_pendidikan');
            $id_agama = $this->input->post('id_agama');
            $tmtmenjabat = $this->input->post('tmtmenjabat');
            $tmtpensiun = $this->input->post('tmtpensiun');
            $nomersk = $this->input->post('nomersk');
            $tanggalsk = $this->input->post('tanggalsk');
            $id_status = $this->input->post('id_status');

            $this->db->set('namalengkap', $namalengkap);
            $this->db->set('tempatlahir', $tempatlahir);
            $this->db->set('tanggallahir', $tanggallahir);
            $this->db->set('id_jabatan', $id_jabatan);
            $this->db->set('rt', $rt);
            $this->db->set('rw', $rw);
            $this->db->set('id_pendidikan', $id_pendidikan);
            $this->db->set('id_agama', $id_agama);
            $this->db->set('tmtmenjabat', $tmtmenjabat);
            $this->db->set('tmtpensiun', $tmtpensiun);
            $this->db->set('nomersk', $nomersk);
            $this->db->set('tanggalsk', $tanggalsk);
            $this->db->set('id_status', $id_status);
            $this->db->where('id_aparatur', $id_aparatur);
            $this->db->update('aparatur');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Desa Berhasil Di Ubah</div>');
            redirect('aparatur/des/' . $id_des);
        }
    }
}
