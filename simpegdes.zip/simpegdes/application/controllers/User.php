<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }


    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->dispay_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your profile has been updated!</div>');
            redirect('user');
        }
    }


    public function changePassword()
    {
        $data['title'] = 'Change Password';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[3]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[3]|matches[new_password1]');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('templates/footer');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');
            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong current password!</div>');
                redirect('user/changepassword');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">New password cannot be the same as current password!</div>');
                    redirect('user/changepassword');
                } else {
                    // password sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password changed!</div>');
                    redirect('user/changepassword');
                }
            }
        }
    }

    // MENU DASHBOARD CONTROLLER => dash
    public function dashboard()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->model('m_dashboard');

        $data['totalkecamatan'] = $this->m_dashboard->getTotalKecamatan();
        $data['totaldesa'] = $this->m_dashboard->getTotalDesa();
        $data['totalkepaladesa'] = $this->m_dashboard->getTotalKepaladesa();
        $data['totalkasipem'] = $this->m_dashboard->getTotalKasiPem();
        $data['totalkasiperen'] = $this->m_dashboard->getTotalKasiPerencanaan();
        $data['totallaki'] = $this->m_dashboard->getTotalLaki();
        $data['totalperempuan'] = $this->m_dashboard->getTotalPerempuan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('dashboard/index', $data);
        $this->load->view('templates/footer');
    }

    // MENU APARATUR CONTROLLER => apar
    public function aparatur()
    {
        $data['title'] = 'Aparatur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/index', $data);
        $this->load->view('templates/footer');
    }

    public function aparkec($id_kec)
    {
        $data['title'] = 'Kecamatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kec'] = $this->db->get_where('kecamatan', ['id_kec' => $id_kec])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_kec' => $id_kec])->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/kec', $data);

        $this->load->view('templates/footer');
    }

    public function apardes($id_des)
    {
        $data['title'] = 'Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_des' => $id_des])->result_array();
        // $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/des', $data);
        $this->load->view('templates/footer');
    }
    public function apartambah($id_des)
    {

        $data['title'] = 'Tambah Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/tambah', $data);
        $this->load->view('templates/footer');
    }

    public function apartambahaparatur($id_des)
    {
        $data['title'] = 'Tambah Desa';

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('tempatlahir', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tanggallahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('id_jabatan', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_pendidikan', 'Pendidikan', 'required');
        $this->form_validation->set_rules('id_agama', 'Agama', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');


        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('aparatur/tambah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert(
                'aparatur',
                [
                    'namalengkap' => $this->input->post('namalengkap'),
                    'tempatlahir' => $this->input->post('tempatlahir'),
                    'tanggallahir' => $this->input->post('tanggallahir'),
                    'id_jabatan' => $this->input->post('id_jabatan'),
                    'id_kec' => $this->input->post('id_kec'),
                    'id_des' => $this->input->post('id_des'),
                    'rt' => $this->input->post('rt'),
                    'rw' => $this->input->post('rw'),
                    'id_pendidikan' => $this->input->post('id_pendidikan'),
                    'tmtmenjabat' => $this->input->post('tmtmenjabat'),
                    'tmtpensiun' => $this->input->post('tmtpensiun'),
                    'id_agama' => $this->input->post('id_agama'),
                    'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                    'nomersk' => $this->input->post('nomersk'),
                    'tanggalsk' => $this->input->post('tanggalsk'),
                    'id_status' => $this->input->post('id_status')
                ]
            );
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur Berhasil Di Tambahkan!</div>');
            redirect('user/apardes/' . $id_des);
        }
    }

    public function apardesdetail($id_aparatur)
    {
        $data['title'] = 'Detail Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/desdetail', $data);
        $this->load->view('templates/footer');
    }

    public function apardesedit($id_aparatur)
    {

        $data['title'] = 'Edit Aparatur Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['aparatur'] = $this->db->get_where('aparatur', ['id_aparatur' => $id_aparatur])->row_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->row_array();
        $data['desa'] = $this->db->get('desa')->row_array();
        $data['status'] = $this->db->get('status')->result_array();
        $data['jekel'] = ['L', 'P'];

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('aparatur/desedit', $data);
        $this->load->view('templates/footer');
    }

    public function apardeseditById($id_des)
    {
        $data['title'] = 'Edit Aparatur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->row_array();
        // $data['aparatur'] = $this->db->get('aparatur')->result_array();

        $this->form_validation->set_rules('namalengkap', 'Nama Lengkap', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('aparatur/des', $data);
            $this->load->view('templates/footer');
        } else {
            $id_aparatur = $this->input->post('id_aparatur');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $tanggallahir = $this->input->post('tanggallahir');
            $id_jabatan = $this->input->post('id_jabatan');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $id_pendidikan = $this->input->post('id_pendidikan');
            $id_agama = $this->input->post('id_agama');
            $tmtmenjabat = $this->input->post('tmtmenjabat');
            $tmtpensiun = $this->input->post('tmtpensiun');
            $nomersk = $this->input->post('nomersk');
            $tanggalsk = $this->input->post('tanggalsk');
            $id_status = $this->input->post('id_status');

            $this->db->set('namalengkap', $namalengkap);
            $this->db->set('tempatlahir', $tempatlahir);
            $this->db->set('tanggallahir', $tanggallahir);
            $this->db->set('id_jabatan', $id_jabatan);
            $this->db->set('rt', $rt);
            $this->db->set('rw', $rw);
            $this->db->set('id_pendidikan', $id_pendidikan);
            $this->db->set('id_agama', $id_agama);
            $this->db->set('tmtmenjabat', $tmtmenjabat);
            $this->db->set('tmtpensiun', $tmtpensiun);
            $this->db->set('nomersk', $nomersk);
            $this->db->set('tanggalsk', $tanggalsk);
            $this->db->set('id_status', $id_status);
            $this->db->where('id_aparatur', $id_aparatur);
            $this->db->update('aparatur');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Aparatur Berhasil Di Ubah</div>');
            redirect('user/apardes/' . $id_des);
        }
    }

    // MENU LAPORAN CONTROLLER => lap
    public function laporan()
    {
        $data['title'] = 'Laporan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['aparatur'] = $this->db->get('aparatur')->result_array();
        $data['jabatan'] = $this->db->get('jabatan')->result_array();
        $data['pendidikan'] = $this->db->get('pendidikan')->result_array();
        $data['agama'] = $this->db->get('agama')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('laporan/index', $data);
        $this->load->view('templates/footer');
    }

    public function get_pilihan()
    {
        $this->load->model('M_kategori', 'dep_kategori', TRUE);
        $pil = $this->input->post('pil');
        $pilih = $this->dep_kategori->get_sub_pilihan($pil);

        $data_tabel = '';
        if (count($pilih) > 0) {
            $i = 1;
            foreach ($pilih as $pi) {
                $data_tabel .= '
                                <tr>
                                    <td>' . $i . '</td>
                                    <td>' . $pi->namalengkap . ' </td>
                                    <td>' . $pi->id_jabatan . ' </td>
                                    <td>' . $pi->id_pendidikan . ' </td>
                                    <td>' . $pi->jenis_kelamin . ' </td>
                                    <td>' . $pi->id_agama . ' </td>
                                </tr>
                                ';
                $i++;
            }
            echo json_encode($data_tabel);
        } elseif (count($pilih) == 0) {

            $alert = '<tr>
                        <td colspan="5" class="text-center" >DATA TIDAK ADA</td>
                     </tr>';
            echo json_encode($alert);
        }
    }
}
