<?php
defined('BASEPATH') or exit('No direct script acces allowed');

class Kodewilayah extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    
    public function index()
    {
        $data['title'] = 'Kode Wilayah';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/index', $data);
        $this->load->view('templates/footer');
    }

    public function kecamatan()
    {
        $data['title'] = 'Kode Wilayah';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();

        $this->form_validation->set_rules('id_kec', 'id_kec', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('id_kab', 'id_kab', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/kecamatan', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert('kecamatan', 
                    [
                    'id_kec' => $this->input->post('id_kec'),
                    'id_kab' => $this->input->post('id_kab'),
                     'nama' => $this->input->post('nama')]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New menu added!</div>');
            redirect('kodewilayah/kecamatan');
        }
    }

    public function editkecamatan($id_kec)
    {
        $data['title'] = 'Ubah Kecamatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kec'] = $this->db->get_where('kecamatan', ['id_kec' => $id_kec])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/editkecamatan', $data);
        $this->load->view('templates/footer');

    }

    public function editkecamatanById()
    {
        $data['title'] = 'Kode Wilayah Kecamatan';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('id_kec', 'Kode Kecamatan', 'required|trim');
        $this->form_validation->set_rules('nama', 'Nama Kecamatan', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/kecamatan', $data);
            $this->load->view('templates/footer');
        } else {
            $id_kec = $this->input->post('id_kec');
            $nama = $this->input->post('nama');
            $id_kab = $this->input->post('id_kab');

            $this->db->set('id_kab', $id_kab);
            $this->db->set('nama', $nama);
            $this->db->where('id_kec', $id_kec);
            $this->db->update('kecamatan');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Ubah</div>');
            redirect('kodewilayah/kecamatan');
        }
    }

    public function hapuskecamatanById($id_kec)
    {
        $this->db->where('id_kec', $id_kec);
        $this->db->delete('kecamatan');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Kecamatan Berhasil Di Hapus</div>');
        redirect('kodewilayah/kecamatan');

    }


    public function desa()
    {
        $data['title'] = 'Kode Wilayah Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['desa'] = $this->db->get('desa')->result_array();
        $data['kecamatan'] = $this->db->get('kecamatan')->result_array();

        $this->form_validation->set_rules('id_kec', 'id_kec', 'required');
        $this->form_validation->set_rules('klasifikasidesa', 'klasifikasidesa', 'required');
        $this->form_validation->set_rules('id_des', 'id_des', 'required');
        $this->form_validation->set_rules('nama', 'nama', 'required');

        if ($this->form_validation->run() == false) {
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/desa', $data);
        $this->load->view('templates/footer');
        } else {
            $this->db->insert('desa',
                [
                    'id_kec' => $this->input->post('id_kec'),
                    'klasifikasidesa' => $this->input->post('klasifikasidesa'),
                    'id_des' => $this->input->post('id_des'),
                    'nama' => $this->input->post('nama'),
                    'id_jenis' => $this->input->post('id_jenis')
                ]
            );
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New menu added!</div>');
            redirect('kodewilayah/desa');
        }
    }

    public function editdesa($id_des)
    {
        $data['title'] = 'Ubah Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['des'] = $this->db->get_where('desa', ['id_des' => $id_des])->row_array();
        $data['klasi']= ['SWASEMBADA', 'SWAKARYA'];

        $this->form_validation->set_rules('nama', 'Nama Desa', 'required|trim');

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kodewilayah/editdesa', $data);
        $this->load->view('templates/footer');
    }

    public function editdesaById()
    {
        $data['title'] = 'Edit Desa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('id_kec', 'Kode Kecamatan', 'required|trim');
        $this->form_validation->set_rules('id_des', 'Kode Desa', 'required|trim');
        $this->form_validation->set_rules('nama', 'Nama Desa', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('kodewilayah/desa', $data);
            $this->load->view('templates/footer');
        } else {
            $id_des = $this->input->post('id_des');
            $id_kec = $this->input->post('id_kec');
            $nama = $this->input->post('nama');
            $klasifikasidesa = $this->input->post('klasifikasidesa');

            $this->db->set('id_kec', $id_kec);
            $this->db->set('nama', $nama);
            $this->db->set('klasifikasidesa', $klasifikasidesa);
            $this->db->where('id_des', $id_des);
            $this->db->update('desa');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Desa Berhasil Di Ubah</div>');
            redirect('kodewilayah/desa');
        }
    }

    public function hapusdesaById($id_des)
    {
        $this->db->where('id_des', $id_des);
        $this->db->delete('desa');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Desa Berhasil Di Hapus</div>');
        redirect('kodewilayah/desa');
    }

}
