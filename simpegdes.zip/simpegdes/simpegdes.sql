-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Feb 2020 pada 06.46
-- Versi server: 10.1.36-MariaDB
-- Versi PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simpegdes`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `agama`
--

CREATE TABLE `agama` (
  `id_agama` int(11) NOT NULL,
  `agama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `agama`
--

INSERT INTO `agama` (`id_agama`, `agama`) VALUES
(1, 'Islam'),
(2, 'Kristen'),
(3, 'Katolik'),
(4, 'Hindu'),
(5, 'Buddha '),
(6, 'Konghucu ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `aparatur`
--

CREATE TABLE `aparatur` (
  `id_aparatur` int(11) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `tempatlahir` varchar(255) NOT NULL,
  `tanggallahir` date NOT NULL,
  `id_jabatan` int(11) NOT NULL,
  `id_kec` char(6) NOT NULL,
  `id_des` char(10) NOT NULL,
  `rt` char(6) NOT NULL,
  `rw` char(6) NOT NULL,
  `id_pendidikan` int(11) NOT NULL,
  `tmtmenjabat` date NOT NULL,
  `tmtpensiun` date NOT NULL,
  `nomersk` varchar(225) NOT NULL,
  `tanggalsk` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `id_agama` int(11) NOT NULL,
  `id_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `aparatur`
--

INSERT INTO `aparatur` (`id_aparatur`, `namalengkap`, `tempatlahir`, `tanggallahir`, `id_jabatan`, `id_kec`, `id_des`, `rt`, `rw`, `id_pendidikan`, `tmtmenjabat`, `tmtpensiun`, `nomersk`, `tanggalsk`, `jenis_kelamin`, `id_agama`, `id_status`) VALUES
(1, 'SUSANTO', 'Kudus', '2020-04-29', 1, '28.00', '28.07.01', '', '', 3, '2013-12-16', '2013-12-17', '141.1/479/2013', '0000-00-00', 'L', 1, 1),
(6, 'HUDDA AMRULLAH', '', '0000-00-00', 2, '28.00', '28.07.01', '', '', 3, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(7, 'SHOLIKHATUN', 'Kudus', '1969-08-05', 3, '28.00', '28.07.01', '', '', 3, '0000-00-00', '0000-00-00', '', '0000-00-00', 'P', 1, 1),
(8, 'NOOR SALIM', 'Kudus', '1967-04-29', 4, '28.00', '28.07.01', '', '', 3, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(9, 'SABURI', 'Kudus', '1955-05-18', 5, '28.00', '28.07.01', '', '', 3, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(10, 'SAMIASIH', 'Kudus', '1954-10-08', 6, '28.00', '28.07.01', '', '', 3, '0000-00-00', '0000-00-00', '', '0000-00-00', 'P', 1, 1),
(11, 'EDY SUTRISNO', 'Kudus', '1984-11-10', 7, '28.00', '28.07.01', '', '', 3, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(12, 'LUTHFI MAULANA RIYANTO', '', '0000-00-00', 8, '28.00', '28.07.01', '', '', 0, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(13, 'SUMADI', 'Kudus', '1969-09-09', 9, '28.00', '28.07.01', '', '', 0, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(14, 'ROFIQ', 'Kudus', '1975-09-01', 10, '28.00', '28.07.01', '', '', 0, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1),
(15, 'SITI MARYANI', 'Kudus', '1979-01-12', 18, '28.00', '28.07.02', '', '', 1, '0000-00-00', '0000-00-00', '', '0000-00-00', 'L', 1, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `desa`
--

CREATE TABLE `desa` (
  `id_des` char(10) NOT NULL,
  `id_kec` char(6) DEFAULT NULL,
  `nama` varchar(225) DEFAULT NULL,
  `klasifikasidesa` varchar(15) NOT NULL,
  `id_jenis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `desa`
--

INSERT INTO `desa` (`id_des`, `id_kec`, `nama`, `klasifikasidesa`, `id_jenis`) VALUES
('28.07.01', '28.00', 'BAKALANKRAPYAK', 'SWASEMBADA', 4),
('28.07.02', '28.00', 'PRAMBATAN KIDUL', 'SWASEMBADA', 4),
('28.07.03', '28.00', 'PRAMBATAN LOR', 'SWAKARYA', 4),
('28.07.04', '28.00', 'GARUNG KIDUL', '', 4),
('28.07.05', '28.00', 'SETROKALANGAN', '', 4),
('28.07.06', '28.00', 'BANGET', '', 4),
('28.07.07', '28.00', 'BLIMBING KIDUL', '', 4),
('28.07.08', '28.00', 'SIDOREKSO', '', 4),
('28.07.09', '28.00', 'GAMONG', '', 4),
('28.07.10', '28.00', 'KEDUNGDOWO', '', 4),
('28.07.11', '28.00', 'GARUNG LOR', '', 4),
('28.07.12', '28.00', 'KARANGAMPEL', '', 4),
('28.07.13', '28.00', 'MIJEN', '', 4),
('28.07.14', '28.00', 'KALIWUNGU', '', 4),
('28.07.15', '28.00', 'PAPRINGAN', '', 4),
('29.08.01', '29.00', 'JANGGALAN', '', 4),
('29.08.02', '29.00', 'DEMANGAN', '', 4),
('29.08.03', '29.00', 'MLATI LOR', '', 4),
('29.08.04', '29.00', 'NGANGUK', '', 4),
('29.08.05', '29.00', 'KRAMAT', '', 4),
('29.08.06', '29.00', 'DEMAAN', '', 4),
('29.08.07', '29.00', 'LANGGARDALEM', '', 4),
('29.08.08', '29.00', 'KAUMAN', '', 4),
('29.08.09', '29.00', 'DAMARAN', '', 4),
('29.08.10', '29.00', 'KRANDON', '', 4),
('29.08.11', '29.00', 'SINGOCANDI', '', 4),
('29.08.12', '29.00', 'GLANTENGAN', '', 4),
('29.08.13', '29.00', 'KALIPUTU', '', 4),
('29.08.14', '29.00', 'BARONGAN', '', 4),
('29.08.15', '29.00', 'BURIKAN', '', 4),
('29.08.16', '29.00', 'RENDENG', '', 4),
('30.07.01', '30.00', 'JETIS KAPUAN', '', 4),
('30.07.02', '30.00', 'TANJUNG KARANG', '', 4),
('30.07.03', '30.00', 'JATI WETAN', '', 4),
('30.07.04', '30.00', 'PASURUAN KIDUL', '', 4),
('30.07.05', '30.00', 'PASURUAN LOR', '', 4),
('30.07.06', '30.00', 'PLOSO', '', 4),
('30.07.07', '30.00', 'JATI KULON', '', 4),
('30.07.08', '30.00', 'GETAS PEJATEN', '', 4),
('30.07.09', '30.00', 'LORAM KULON', '', 4),
('30.07.10', '30.00', 'LORAM WETAN', '', 4),
('30.07.11', '30.00', 'JEPANG PAKIS', '', 4),
('30.07.12', '30.00', 'MEGAWON', '', 4),
('30.07.13', '30.00', 'NGEMBAL KULON', '', 4),
('30.07.14', '30.00', 'TUMPANG KRASAK', '', 4),
('31.07.01', '31.00', 'WONOSOCO', '', 4),
('31.07.02', '31.00', 'LAMBANGAN', '', 4),
('31.07.03', '31.00', 'KALIREJO', '', 4),
('31.07.04', '31.00', 'MEDINI', '', 4),
('31.07.05', '31.00', 'SAMBUNG', '', 4),
('31.07.06', '31.00', 'GLAGAHWARU', '', 4),
('31.07.07', '31.00', 'KUTUK', '', 4),
('31.07.08', '31.00', 'UNDAAN KIDUL', '', 4),
('31.07.09', '31.00', 'UNDAAN TENGAH', '', 4),
('31.07.10', '31.00', 'KARANG ROWO', '', 4),
('31.07.11', '31.00', 'LARIKREJO', '', 4),
('31.07.12', '31.00', 'UNDAAN LOR', '', 4),
('31.07.13', '31.00', 'WATES', '', 4),
('31.07.14', '31.00', 'NGEMPLAK', '', 4),
('31.07.15', '31.00', 'TERANGMAS', '', 4),
('31.07.16', '31.00', 'BERUGENJANG', '', 4),
('32.07.01', '32.00', 'GULANG', '', 4),
('32.07.02', '32.00', 'JEPANG', '', 4),
('32.07.03', '32.00', 'PAYAMAN', '', 4),
('32.07.04', '32.00', 'KIRIG', '', 4),
('32.07.05', '32.00', 'TEMULUS', '', 4),
('32.07.06', '32.00', 'KESAMBI', '', 4),
('32.07.07', '32.00', 'JOJO', '', 4),
('32.07.08', '32.00', 'HADIWARNO', '', 4),
('32.07.09', '32.00', 'MEJOBO', '', 4),
('32.07.10', '32.00', 'GOLANTEPUS', '', 4),
('32.07.11', '32.00', 'TENGGELES', '', 4),
('33.07.01', '33.00', 'SADANG', '', 4),
('33.07.02', '33.00', 'BULUNG CANGKRING', '', 4),
('33.07.03', '33.00', 'BULUNG KULO', '', 4),
('33.07.04', '33.00', 'SIDOMULYO', '', 4),
('33.07.05', '33.00', 'GONDOHARUM', '', 4),
('33.07.06', '33.00', 'TERBAN', '', 4),
('33.07.07', '33.00', 'PLADEN', '', 4),
('33.07.08', '33.00', 'KLALING', '', 4),
('33.07.09', '33.00', 'JEKULO', '', 4),
('33.07.10', '33.00', 'HADIPOLO', '', 4),
('33.07.11', '33.00', 'HONGGOSOCO', '', 4),
('33.07.12', '33.00', 'TANJUNG REJO', '', 4),
('34.06.01', '34.00', 'DERSALAM', '', 4),
('34.06.02', '34.00', 'NGEMBAL REJO', '', 4),
('34.06.03', '34.00', 'KARANG BENER', '', 4),
('34.06.04', '34.00', 'GONDANG MANIS', '', 4),
('34.06.05', '34.00', 'PEDAWANG', '', 4),
('34.06.06', '34.00', 'BACIN', '', 4),
('34.06.07', '34.00', 'PANJANG', '', 4),
('34.06.08', '34.00', 'PEGANJARAN', '', 4),
('34.06.09', '34.00', 'PURWOREJO', '', 4),
('34.06.10', '34.00', 'BAE', '', 4),
('35.07.01', '35.00', 'GRIBIG', '', 4),
('35.07.02', '35.00', 'KLUMPIT', '', 4),
('35.07.03', '35.00', 'GETASRABI', '', 4),
('35.07.04', '35.00', 'PADURENAN', '', 4),
('35.07.05', '35.00', 'KARANG MALANG', '', 4),
('35.07.06', '35.00', 'BESITO', '', 4),
('35.07.07', '35.00', 'JURANG', '', 4),
('35.07.08', '35.00', 'GONDOSARI', '', 4),
('35.07.09', '35.00', 'KEDUNG SARI', '', 4),
('35.07.10', '35.00', 'MENAWAN', '', 4),
('35.07.11', '35.00', 'RAHTAWU', '', 4),
('36.07.01', '36.00', 'SAMIREJO', '', 4),
('36.07.02', '36.00', 'CENDONO', '', 4),
('36.07.03', '36.00', 'MARGOREJO', '', 4),
('36.07.04', '36.00', 'REJOSARI', '', 4),
('36.07.05', '36.00', 'KANDANG MAS', '', 4),
('36.07.06', '36.00', 'GLAGAH KULON', '', 4),
('36.07.07', '36.00', 'TERGO', '', 4),
('36.07.08', '36.00', 'CRANGGANG', '', 4),
('36.07.09', '36.00', 'LAU', '', 4),
('36.07.10', '36.00', 'PIJI', '', 4),
('36.07.11', '36.00', 'PUYOH', '', 4),
('36.07.12', '36.00', 'SOCO', '', 4),
('36.07.13', '36.00', 'TERNADI', '', 4),
('36.07.14', '36.00', 'KAJAR', '', 4),
('36.07.15', '36.00', 'KUWUKAN', '', 4),
('36.07.16', '36.00', 'DUKUH WARINGIN', '', 4),
('36.07.17', '36.00', 'JAPAN', '', 4),
('36.07.18', '36.00', 'COLO', '', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL,
  `jabatan` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `jabatan`) VALUES
(1, 'Kepala Desa'),
(2, 'Sekretaris Desa'),
(3, 'Kepala Seksi Pemerintahan'),
(4, 'Kepala Seksi Kesejahteraan'),
(5, 'Kepala Seksi Pelayanan'),
(6, 'Kepala Urusan Tata Usaha dan Umum'),
(7, 'Kepala Urusan Keuangan'),
(8, 'Kepala Urusan Perencanaan'),
(9, 'Kepala Dusun I'),
(10, 'Kepala Dusun II'),
(11, 'Kepala Dusun III'),
(12, 'Kepala Dusun IV'),
(13, 'Staf'),
(14, 'Staf Seksi Pemerintahan'),
(15, 'Staf Seksi Kesejahteraan'),
(16, 'Staf Seksi Pelayanan'),
(17, 'Staf Urusan Tata Usaha dan Umum'),
(18, 'Staf Urusan Keuangan'),
(19, 'Staf Urusan Perencanaan'),
(20, 'Staf Dusun');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kecamatan`
--

CREATE TABLE `kecamatan` (
  `id_kec` char(6) NOT NULL,
  `id_kab` char(4) NOT NULL,
  `nama` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kecamatan`
--

INSERT INTO `kecamatan` (`id_kec`, `id_kab`, `nama`) VALUES
('28.00', 'C1', 'KALIWUNGU'),
('29.00', '\0\0C1', 'KOTA KUDUS'),
('30.00', '\0\0C1', 'JATI'),
('31.00', '\0\0C1', 'UNDAAN'),
('32.00', '\0\0C1', 'MEJOBO'),
('33.00', '\0\0C1', 'JEKULO'),
('34.00', '\0\0C1', 'BAE'),
('35.00', '\0\0C1', 'GEBOG'),
('36.00', '', 'DAWE');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendidikan`
--

CREATE TABLE `pendidikan` (
  `id_pendidikan` int(11) NOT NULL,
  `pendidikan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendidikan`
--

INSERT INTO `pendidikan` (`id_pendidikan`, `pendidikan`) VALUES
(1, 'SD'),
(2, 'SLTP'),
(3, 'SLTA'),
(4, 'D3'),
(5, 'S1'),
(6, 'S2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `status`
--

CREATE TABLE `status` (
  `id_status` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `status`
--

INSERT INTO `status` (`id_status`, `status`) VALUES
(0, 'Non-aktif'),
(1, 'Aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(3, 'Muhamad Sholikhudin', 'siapasaya065@gmail.com', 'default.jpg', '$2y$10$nyuZaIsp33TOPD7v3/MJSujVlec46hR3SRQrHcf8sBcCz12CiLIQO', 2, 1, 1571243073),
(4, 'DINPMD', 'dinaspmd@gmail.com', 'default.jpg', '$2y$10$eXTQJbpwweKydR2k2MjLLufNMMh/4KgeJAH37w8rS3.q44F51Mav2', 1, 1, 1577639684),
(5, 'Yudha Prasetiyo', 'yudha@gmail.com', 'default.jpg', '$2y$10$JvC233WD4InQg/u49dSx9OIrrRJQq2v5aAuLxOuv69lkil7ngXmFq', 2, 1, 1581642655),
(6, 'Adnan', 'adnan@gmail.com', 'default.jpg', '$2y$10$rI7Bj7mZltM8iEqhwy4z1e3/VzH6iRlsEZ1tA6gZ1F5MRXshuy7NC', 2, 1, 1582116127);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 0),
(5, 2, 2),
(6, 2, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Menu'),
(2, 'Admin'),
(3, 'User'),
(4, 'Test'),
(5, 'Laporan'),
(6, 'Data'),
(7, 'Jabatan'),
(8, 'Kodewilayah'),
(9, 'Pengguna'),
(10, 'Dashboard'),
(11, 'Aparatur');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Member');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 2, 'Admin', 'admin/index', 'fas fa-fw fa-tachometer-alt', 1),
(2, 1, 'Dashboard', 'user/dashboard', 'fas fa-fw fa-tachometer-alt', 1),
(3, 3, 'My Profile', 'user', 'fas fa-fw fa-user-alt', 1),
(4, 3, 'Edit Profile', 'user/edit', 'fas fa-fw fa-user-edit', 1),
(5, 4, 'Menu Management', 'menu', 'fas fa-fw fa-folder', 1),
(6, 4, 'SubMenu Management', 'menu/submenu', 'fas fa-fw fa-folder-open', 1),
(8, 3, 'Change Password', 'user/changepassword', 'fas fa-fw fa-key', 1),
(9, 1, 'Aparatur', 'user/aparatur', 'fas fa-fw fa-users', 1),
(10, 2, 'Jabatan', 'admin/jab', 'far fa-fw fa-address-card', 1),
(11, 2, 'Kode Wilayah', 'admin/kodewilayah', 'fas fa-fw fa-map-marker-alt', 1),
(15, 2, 'Data Master', 'admin/data', 'fas fa-fw fa-folder-open', 1),
(16, 1, 'Laporan', 'user/laporan', 'fas fa-fw fa-file-alt', 1),
(17, 2, 'Pengguna', 'admin/pengguna', 'fas fa-fw fa-user-alt', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`id_agama`);

--
-- Indeks untuk tabel `aparatur`
--
ALTER TABLE `aparatur`
  ADD PRIMARY KEY (`id_aparatur`);

--
-- Indeks untuk tabel `desa`
--
ALTER TABLE `desa`
  ADD PRIMARY KEY (`id_des`);

--
-- Indeks untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indeks untuk tabel `kecamatan`
--
ALTER TABLE `kecamatan`
  ADD PRIMARY KEY (`id_kec`);

--
-- Indeks untuk tabel `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indeks untuk tabel `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `agama`
--
ALTER TABLE `agama`
  MODIFY `id_agama` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `aparatur`
--
ALTER TABLE `aparatur`
  MODIFY `id_aparatur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id_jabatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `id_pendidikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `status`
--
ALTER TABLE `status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
